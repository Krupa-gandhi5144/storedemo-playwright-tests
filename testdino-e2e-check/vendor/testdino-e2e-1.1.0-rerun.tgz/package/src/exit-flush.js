// Sends the events a forced stop left undelivered. The reporter runs this as a
// child it waits on synchronously, because e2e calls process.exit() without
// waiting for reporters. Input on stdin: { channel, url, token, kafka, events }.
import { createRequire } from 'node:module';

const chunks = [];
for await (const chunk of process.stdin) chunks.push(chunk);
const { channel, url, token, kafka, events } = JSON.parse(Buffer.concat(chunks).toString('utf8'));

async function sendHttp() {
  if (!url) throw new Error('no HTTP endpoint');
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    body: JSON.stringify({ events }),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
}

async function sendKafka() {
  const { Kafka, Partitioners, logLevel } = createRequire(import.meta.url)('kafkajs');
  const producer = new Kafka({
    clientId: `testdino-e2e-exit-${events[0].runId.slice(0, 8)}`,
    brokers: kafka.brokers,
    connectionTimeout: 3_000,
    requestTimeout: 3_000,
    retry: { retries: 0 },
    logLevel: logLevel.NOTHING,
    ...(kafka.sasl && { sasl: { ...kafka.sasl, mechanism: kafka.sasl.mechanism.toLowerCase() } }),
    ...(kafka.ssl !== undefined && { ssl: kafka.ssl }),
  }).producer({ createPartitioner: Partitioners.DefaultPartitioner });
  await producer.connect();
  try {
    await producer.send({
      topic: kafka.channel,
      acks: 1,
      messages: events.map((event) => ({ key: event.runId, value: JSON.stringify(event) })),
    });
  } finally {
    await producer.disconnect().catch(() => {});
  }
}

try {
  if (channel === 'kafka') await sendKafka().catch(sendHttp);
  else await sendHttp();
} catch {
  process.exitCode = 1;
}
