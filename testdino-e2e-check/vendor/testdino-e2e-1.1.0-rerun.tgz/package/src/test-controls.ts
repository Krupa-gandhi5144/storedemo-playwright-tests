// Test Controls (quarantine, known errors, critical tests) deciding the build
// result, as @testdino/playwright decides it (src/reporter/test-controls.ts).
// A reporter cannot change e2e's exit code, so the decision is written for
// `testdino-e2e run`, which applies it.

export interface QuarantineList {
  quarantined: string[];
  knownErrors: { testIds: string[]; pattern: string }[];
  critical: string[];
  // One per rule; absent on servers older than the count.
  rules?: { quarantined: number; knownErrors: number; critical: number };
}

export type QuarantineUnavailableReason = 'unreachable' | 'timeout' | 'not_found';
export type QuarantineFetchOutcome = { list: QuarantineList } | { reason: QuarantineUnavailableReason };

export interface RunQuarantineBlock {
  state: 'applied' | 'not_applied';
  reason?: QuarantineUnavailableReason;
  testIds?: string[];
  criticalFlakyTestIds?: string[];
  build: 'passed' | 'failed';
}

export interface FinishedTest {
  id: string;
  title: string;
  outcome: 'expected' | 'unexpected' | 'flaky' | 'skipped';
  /** Message of the final attempt's first error; empty when it has none. */
  errorMessage: string;
}

export interface TestControlsDecision {
  block: RunQuarantineBlock;
  /** The build result when Test Controls changes it; undefined leaves e2e's. */
  status?: 'passed' | 'failed';
  report: string[];
}

const QUARANTINE_PATH = '/api/v1/reporter/quarantine';
const QUARANTINE_TIMEOUT_MS = 5_000;

const ids = (value: unknown): string[] =>
  Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string') : [];

// A body without the list is not a list: recorded as not applied, never as an
// applied empty one that forgives nothing.
export function normalizeQuarantineList(raw: unknown): QuarantineList | undefined {
  const data = (raw ?? {}) as Record<string, unknown>;
  if (!Array.isArray(data.quarantined)) return undefined;
  const r = (data.rules ?? {}) as Record<string, unknown>;
  const count = (v: unknown): v is number => typeof v === 'number' && Number.isInteger(v) && v >= 0;
  return {
    quarantined: ids(data.quarantined),
    critical: ids(data.critical),
    knownErrors: Array.isArray(data.knownErrors)
      ? (data.knownErrors as { testIds?: unknown; pattern?: unknown }[])
          .filter((k) => k && typeof k.pattern === 'string')
          .map((k) => ({ testIds: ids(k.testIds), pattern: k.pattern as string }))
      : [],
    ...(count(r.quarantined) &&
      count(r.knownErrors) &&
      count(r.critical) && { rules: { quarantined: r.quarantined, knownErrors: r.knownErrors, critical: r.critical } }),
  };
}

export async function fetchQuarantineList(serverUrl: string, token: string): Promise<QuarantineFetchOutcome> {
  try {
    const response = await fetch(`${serverUrl.replace(/\/+$/, '')}${QUARANTINE_PATH}`, {
      headers: { authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(QUARANTINE_TIMEOUT_MS),
    });
    if (response.status === 404) return { reason: 'not_found' };
    if (!response.ok) return { reason: 'unreachable' };
    const list = normalizeQuarantineList(await response.json().catch(() => undefined));
    return list ? { list } : { reason: 'unreachable' };
  } catch (error) {
    return { reason: error instanceof Error && error.name === 'TimeoutError' ? 'timeout' : 'unreachable' };
  }
}

// eslint-disable-next-line no-control-regex -- stripping ANSI is the point
const ANSI = /\u001b\[[0-9;]*m/g;

/** The line a known-error pattern is tested against, the shape the server builds patterns for. */
export function firstErrorLine(message: string): string {
  for (const raw of message.replace(ANSI, '').split('\n')) {
    const line = raw.replace(/\s+/g, ' ').trim();
    if (line) return line;
  }
  return '';
}

// A pattern that does not compile forgives nothing.
function compileKnownErrors(list: QuarantineList) {
  return list.knownErrors.flatMap((entry) => {
    try {
      return [{ testIds: new Set(entry.testIds), pattern: new RegExp(entry.pattern) }];
    } catch {
      return [];
    }
  });
}

const UNAVAILABLE_TEXT: Record<QuarantineUnavailableReason, string> = {
  unreachable: "couldn't reach TestDino",
  timeout: 'TestDino did not answer in time',
  not_found: 'the project was not found',
};

const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;

function rulesLine(list: QuarantineList): string {
  const counts = list.rules;
  if (!counts) return 'Test Controls: rules loaded';
  const parts = [
    counts.quarantined > 0 && `${counts.quarantined} quarantined`,
    counts.knownErrors > 0 && plural(counts.knownErrors, 'known error', 'known errors'),
    counts.critical > 0 && `${counts.critical} critical`,
  ].filter(Boolean);
  const total = counts.quarantined + counts.knownErrors + counts.critical;
  return `Test Controls: ${plural(total, 'rule', 'rules')}${parts.length > 0 ? ` (${parts.join(', ')})` : ''}`;
}

export interface TestControlsInput {
  fetch: QuarantineFetchOutcome;
  tests: FinishedTest[];
  runStatus: 'passed' | 'failed' | 'interrupted';
  /** e2e's exit code: only a pass (0) or test failure (1) can be changed. */
  exitCode: number;
  globalErrorCount: number;
}

/**
 * Quarantined and known-error failures stop failing the build only when every
 * unexpected test is forgiven, nothing failed outside a test, and the run ended
 * a plain failure. A critical test that passed only on retry fails the build.
 * Without the list, nothing changes.
 */
export function decideTestControls(input: TestControlsInput): TestControlsDecision {
  const decision = decide(input);
  const build = decision.status ?? (input.runStatus === 'passed' ? 'passed' : 'failed');
  return { ...decision, block: { ...decision.block, build } };
}

type Decided = Omit<TestControlsDecision, 'block'> & { block: Omit<RunQuarantineBlock, 'build'> };

function decide(input: TestControlsInput): Decided {
  if (!('list' in input.fetch)) {
    const { reason } = input.fetch;
    return {
      block: { state: 'not_applied', reason },
      report: [`Test Controls: rules not loaded (${UNAVAILABLE_TEXT[reason]}); failures count as usual`],
    };
  }

  const { list } = input.fetch;
  const quarantined = new Set(list.quarantined);
  const critical = new Set(list.critical);
  const knownErrors = compileKnownErrors(list);
  const isKnownErrorTest = (id: string) => knownErrors.some((k) => k.testIds.has(id));
  const matchesKnownError = (test: FinishedTest) => {
    const line = firstErrorLine(test.errorMessage);
    return knownErrors.some((k) => k.testIds.has(test.id) && k.pattern.test(line));
  };

  const testIds: string[] = [];
  const forgiven = new Set<string>();
  const criticalFlaky: FinishedTest[] = [];
  const unexpected: FinishedTest[] = [];
  for (const test of input.tests) {
    if (test.outcome === 'skipped') continue;
    if (test.outcome === 'unexpected') unexpected.push(test);
    if (test.outcome === 'flaky' && critical.has(test.id)) criticalFlaky.push(test);
    if (quarantined.has(test.id)) {
      testIds.push(test.id);
      if (test.outcome === 'unexpected') forgiven.add(test.id);
    } else if (isKnownErrorTest(test.id)) {
      if (test.outcome !== 'unexpected') {
        testIds.push(test.id);
      } else if (matchesKnownError(test)) {
        testIds.push(test.id);
        forgiven.add(test.id);
      }
    }
  }

  const block: Decided['block'] = {
    state: 'applied',
    ...(testIds.length > 0 && { testIds }),
    ...(criticalFlaky.length > 0 && { criticalFlakyTestIds: criticalFlaky.map((t) => t.id) }),
  };
  const report = [rulesLine(list)];
  if (testIds.length === 0 && criticalFlaky.length === 0) return { block, report };

  const excluded = forgiven.size;
  if (testIds.length > 0) {
    const failed = excluded > 0 ? `${excluded} failed, excluded from the build` : 'none failed';
    report.push(`Quarantined tests in this run: ${testIds.length} (${failed})`);
  }
  const isPlainEnd = (input.runStatus === 'passed' || input.runStatus === 'failed') && input.exitCode <= 1;
  if (isPlainEnd && criticalFlaky.length > 0) {
    const what = criticalFlaky.length === 1 ? 'critical test' : 'critical tests';
    report.push(`Build fails: ${what} passed only on retry (${criticalFlaky.map((t) => t.title).join(', ')})`);
    return { block, status: 'failed', report };
  }
  if (!isPlainEnd) {
    report.push(`The run ended ${input.runStatus} (exit ${input.exitCode}), so its status stands`);
    return { block, report };
  }
  const stillFailing = unexpected.filter((t) => !forgiven.has(t.id)).length;
  if (stillFailing > 0) {
    report.push(`Build fails: ${plural(stillFailing, 'failure', 'failures')} not quarantined`);
    return { block, report };
  }
  if (input.globalErrorCount > 0) {
    report.push('Build fails: an error outside a test');
    return { block, report };
  }
  if (excluded > 0) {
    report.push('Build passes: every failure was quarantined');
    return { block, status: input.runStatus === 'failed' ? 'passed' : undefined, report };
  }
  report.push('No failures');
  return { block, report };
}
