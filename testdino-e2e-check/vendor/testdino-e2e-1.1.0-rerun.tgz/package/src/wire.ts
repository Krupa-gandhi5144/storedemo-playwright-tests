// Maps an e2e report onto the TestDino reporter wire protocol (the event stream
// the ingestion service reads). Pure: no I/O, so the mapping is unit-testable.
import type { RunQuarantineBlock } from './test-controls.ts';
import { createHash } from 'node:crypto';
import { relative, sep } from 'node:path';
import type { Report } from 'e2e';

type Run = Report['run'];
type Result = Run['results'][number];
type Attempt = Result['attempts'][number];
type Step = Attempt['steps'][number];
type Artifact = Attempt['artifacts'][number];
type ReportError = NonNullable<Attempt['error']>;
// Newer e2e reports `viewport` (0.21.3 does); the 0.16 types this package builds against lack it.
type FailureEvidence = NonNullable<Attempt['failure']> & { viewport?: { width: number; height: number } };

export interface Location {
  file: string;
  line: number;
  column: number;
}

export interface WireError {
  message: string;
  stack: string;
  snippet: string;
  location?: Location;
}

export interface WireAttachment {
  name: string;
  contentType: string;
  blobKey?: string;
  unavailable?: boolean;
}

interface Envelope {
  runId: string;
  timestamp: number;
  sequence: number;
}

export interface SkeletonTest {
  testId: string;
  title: string;
  location: Location;
  expectedStatus: string;
}

export interface SkeletonSuite {
  title: string;
  type: 'project' | 'file' | 'describe';
  file?: string;
  location?: Location;
  tests: SkeletonTest[];
  suites: SkeletonSuite[];
}

export interface Skeleton {
  totalTests: number;
  suites: SkeletonSuite[];
}

export interface TestBeginEvent extends Envelope {
  type: 'test:begin';
  testId: string;
  title: string;
  titlePath: string[];
  location: Location;
  tags: string[];
  expectedStatus: 'passed' | 'skipped';
  timeout: number;
  retries: number;
  retry: number;
  annotations: { type: string; description?: string }[];
  workerIndex: number;
  parallelIndex: number;
  repeatEachIndex: number;
  parentSuite: { title: string; type: 'file' | 'describe'; location: Location };
  startTime: number;
}

export interface StepBeginEvent extends Envelope {
  type: 'step:begin';
  testId: string;
  stepId: string;
  title: string;
  titlePath: string[];
  category: string;
  startTime: number;
  retry: number;
  workerIndex: number;
  parallelIndex: number;
  annotations: [];
  location?: Location;
}

export interface StepEndEvent extends Envelope {
  type: 'step:end';
  testId: string;
  stepId: string;
  title: string;
  titlePath: string[];
  duration: number;
  status: 'passed' | 'failed';
  childSteps: { count: 0; steps: [] };
  attachments: [];
  annotations: [];
  retry: number;
  workerIndex: number;
  parallelIndex: number;
  error?: WireError;
}

export interface TestEndEvent extends Envelope {
  type: 'test:end';
  testId: string;
  status: 'passed' | 'failed' | 'skipped' | 'timedOut' | 'interrupted';
  outcome: 'expected' | 'unexpected' | 'flaky' | 'skipped';
  duration: number;
  retry: number;
  workerIndex: number;
  parallelIndex: number;
  annotations: { type: string; description?: string }[];
  errors: WireError[];
  steps: { total: number; passed: number; failed: number };
  attachments: WireAttachment[];
  stdout?: string[];
  stderr?: string[];
}

export interface RunErrorEvent extends Envelope {
  type: 'run:error';
  message: string;
}

/** One position of a sharded or split run: 1-based `current` of `total`. */
export interface Slice {
  current: number;
  total: number;
}

export interface RunHeartbeatEvent extends Envelope {
  type: 'run:heartbeat';
}

export interface RunEndEvent extends Envelope {
  type: 'run:end';
  status: 'passed' | 'failed' | 'interrupted';
  duration: number;
  startTime: number;
  shard?: Slice;
  splitId?: string;
  split?: Slice;
  // What ingestion's completeness check compares the stored rows against.
  executedTests?: number;
  executedAttempts?: number;
  retriedTests?: Record<string, number>;
  retriedTestsTruncated?: true;
  // What Test Controls decided, sent only when `testdino-e2e run` applies it.
  quarantine?: RunQuarantineBlock;
}

export interface RunSelectionReport {
  id: string;
  onMissing: 'skip' | 'fail';
  // Both count test-list lines, not tests.
  requested: number;
  matched: number;
  notFound: { testId: string; line: string }[];
}

export interface RunBeginEvent extends Envelope {
  type: 'run:begin';
  projectId: string;
  ciRunId?: string;
  shard?: Slice;
  splitId?: string;
  split?: Slice;
  tags?: string[];
  /** The run this one re-runs the failed tests of. */
  rerunOf?: string;
  // How a `testdino-e2e run --selection` run matched its stored test selection.
  selection?: RunSelectionReport;
  metadata: {
    git: unknown;
    ci: unknown;
    system: unknown;
    framework: { name: 'e2e'; version: string };
    // The server keys suite identity and the platform column on this block's
    // project names, so each e2e target is declared here as a project; shards
    // of one run are merged by this block's `shard` together with `ciRunId`.
    playwright: { projects: { name: string }[]; shard?: Slice };
    skeleton: Skeleton;
  };
}

/** Parses "2/3" into a slice; undefined for anything else, including a 1-of-1. */
export function parseSlice(value: string | undefined): Slice | undefined {
  const match = /^\s*(\d+)\s*\/\s*(\d+)\s*$/.exec(value ?? '');
  if (!match) return undefined;
  const current = Number(match[1]);
  const total = Number(match[2]);
  if (total < 2 || current < 1 || current > total) return undefined;
  return { current, total };
}

/** The `--shard index/total` a run was started with, read from the command line e2e received. */
export function shardFromArgv(argv: readonly string[]): string | undefined {
  for (let index = 0; index < argv.length; index++) {
    const arg = argv[index]!;
    if (arg === '--shard') return argv[index + 1];
    if (arg.startsWith('--shard=')) return arg.slice('--shard='.length);
  }
  return undefined;
}

export interface TestAttachmentsEvent extends Envelope {
  type: 'test:attachments';
  testId: string;
  retry: number;
  attachments: WireAttachment[];
}

export type WireEvent =
  | RunBeginEvent
  | TestBeginEvent
  | StepBeginEvent
  | StepEndEvent
  | TestEndEvent
  | TestAttachmentsEvent
  | RunHeartbeatEvent
  | RunErrorEvent
  | RunEndEvent;

type Unstamped<Event> = Omit<Event, 'runId' | 'sequence'>;

export interface PlannedAttempt {
  begin: Unstamped<TestBeginEvent>;
  steps: (Unstamped<StepBeginEvent> | Unstamped<StepEndEvent>)[];
  end: Unstamped<TestEndEvent>;
  artifacts: Artifact[];
}

export interface PlannedTest {
  testId: string;
  /** What e2e's own events call this test, to route captured output to it. */
  identity: { testId: string; targetId: string; agent: string; repeat: number };
  attempts: PlannedAttempt[];
}

export interface RunPlan {
  runId: string;
  startTime: number;
  frameworkVersion: string;
  targets: string[];
  skeleton: Skeleton;
  tests: PlannedTest[];
  runErrors: Unstamped<RunErrorEvent>[];
  end: Unstamped<RunEndEvent>;
}

// The attempt fields both an ordinary test and a serial-group member carry.
interface AttemptView {
  index: number;
  status: Attempt['status'];
  startedAt: string;
  durationMs: number;
  steps: readonly Step[];
  artifacts: readonly Artifact[];
  error?: ReportError | undefined;
  failure?: FailureEvidence | undefined;
  appLog?: readonly AppLogLine[] | undefined;
  skipReason?: string | undefined;
}

const ATTEMPT_STATUS: Record<Attempt['status'], TestEndEvent['status']> = {
  passed: 'passed',
  failed: 'failed',
  'timed-out': 'timedOut',
  interrupted: 'interrupted',
  skipped: 'skipped',
};

const RUN_STATUS: Record<Run['status'], RunEndEvent['status']> = {
  passed: 'passed',
  failed: 'failed',
  // A blocked or errored run did not pass; the wire has no closer status.
  blocked: 'failed',
  error: 'failed',
  interrupted: 'interrupted',
};

const ATTEMPT_FALLBACK: Record<Result['status'], Attempt['status']> = {
  passed: 'passed',
  flaky: 'passed',
  failed: 'failed',
  'timed-out': 'timed-out',
  interrupted: 'interrupted',
  skipped: 'skipped',
};

// The server and the rerun flow accept only [A-Za-z0-9_-]{1,128} as a test id,
// and need one id per test, target, agent, and repeat. e2e's own test id is a
// path with separators, so it is hashed together with what makes a result unique.
export function wireTestId(result: Pick<Result, 'testId' | 'targetId' | 'agent' | 'repeat'>): string {
  return createHash('sha1')
    .update([result.targetId, result.agent, String(result.repeat), result.testId].join('\u0000'))
    .digest('hex');
}

function toLocation(source: { file: string; line: number; column: number } | undefined, file: string): Location {
  return source ? { file: source.file, line: source.line, column: source.column } : { file, line: 0, column: 0 };
}

const MAX_CANDIDATES = 5;
const MAX_LINE = 1000;
// e2e numbers nodes per screen observation, so a retry failing the same way names the same element with another id.
const NODE_ID = /^#n\d+\s+/;

function clip(text: string): string {
  return text.length > MAX_LINE ? `${text.slice(0, MAX_LINE)}…` : text;
}

// A user:password, query string or fragment can carry a secret; the rest of the
// address, scheme included (about:, chrome-error:, an app's own), is kept.
export function safeUrl(url: string): string {
  try {
    const parsed = new URL(url);
    // A blob: address wraps its origin's URL, which can carry its own user:password.
    if (parsed.protocol === 'blob:') return `blob:${safeUrl(parsed.pathname)}`;
    parsed.username = '';
    parsed.password = '';
    parsed.search = '';
    parsed.hash = '';
    return parsed.href;
  } catch {
    return (url.split(/[?#]/)[0] ?? '').replace(/\/\/[^/@]*@/, '//');
  }
}

// Ends only at whitespace, a quote or an angle bracket: `)` and `'` can sit inside a
// query string, and ending there would leave the rest of the query in the line.
// A scheme starts where no scheme character comes before it, so `x_https://…` is caught too.
const URL_TOKEN = /(?<![a-z0-9+.-])(?:[a-z][a-z0-9+.-]*:\/\/|about:)[^\s"<>]+/gi;
// Closing punctuation after an address (`(at …:12:7)`, `'…'`, `[…]`), kept as written.
const TRAILING = /[)'\]]+$/;
// A stack-style `:line:col` after a script's query string, kept when the query goes.
const SOURCE_POSITION = /(?::\d+){1,2}$/;

function withSafeUrls(text: string): string {
  return text.replace(URL_TOKEN, (token) => {
    const trailing = TRAILING.exec(token)?.[0] ?? '';
    const address = token.slice(0, token.length - trailing.length);
    const position = /[?#]/.test(address) ? (SOURCE_POSITION.exec(address)?.[0] ?? '') : '';
    return safeUrl(address.slice(0, address.length - position.length)) + position + trailing;
  });
}

// What e2e saw at the failure. It goes in the stack the dashboard shows, never
// the message: the server groups and categorizes failures on the message text.
function failureDetails(message: string, explanation?: string, failure?: FailureEvidence): string[] {
  const lines: string[] = [];
  if (explanation && !message.includes(explanation)) lines.push(`AI judgment: ${clip(explanation)}`);
  const where = [
    failure?.url && safeUrl(failure.url),
    failure?.viewport && `${failure.viewport.width}×${failure.viewport.height}`,
  ].filter(Boolean);
  if (where.length > 0) lines.push(`Page at failure: ${where.join(', ')}`);
  const candidates = failure?.candidates?.slice(0, MAX_CANDIDATES) ?? [];
  if (candidates.length > 0)
    lines.push('Closest matches on screen:', ...candidates.map((line) => `  ${clip(line.replace(NODE_ID, ''))}`));
  return lines;
}

function toWireError(error: ReportError, explanation?: string, failure?: FailureEvidence): WireError {
  // The wire has no error-code field; the code leads the message so it survives.
  const message = `${error.code}: ${error.message}`;
  return {
    message,
    stack: [message, ...failureDetails(message, explanation, failure)].join('\n'),
    snippet: '',
    ...(error.source && { location: toLocation(error.source, error.source.file) }),
  };
}

// What the app logged during an attempt. Newer e2e reports it; the 0.16 types
// this package builds against lack it.
interface AppLogLine {
  source: string;
  level: 'error' | 'warning' | 'info';
  text: string;
  at: string;
  step?: number;
}

const MAX_APP_LOG_LINES = 200;

function appLogOf(record: object): readonly AppLogLine[] | undefined {
  return (record as { appLog?: readonly AppLogLine[] }).appLog;
}

// Each app log line as a console line on the dashboard: errors to stderr, the
// rest to stdout, naming the source and the step it happened in.
function appConsole(view: AttemptView): { stdout?: string[]; stderr?: string[] } {
  const lines = view.appLog ?? [];
  if (lines.length === 0) return {};
  const stdout: string[] = [];
  const stderr: string[] = [];
  // The newest lines are the ones next to the failure.
  for (const line of lines.slice(-MAX_APP_LOG_LINES)) {
    const step = view.steps.find((candidate) => candidate.index === line.step);
    const label = `App ${line.source}${line.level === 'warning' ? ' warning' : ''}${step ? ` in ${stepTitle(step)}` : ''}`;
    const text = withSafeUrls(line.text);
    (line.level === 'error' ? stderr : stdout).push(`${label}: ${text}`);
  }
  const dropped = lines.length - MAX_APP_LOG_LINES;
  if (dropped > 0) stdout.unshift(`${dropped} earlier app log lines not shown.`);
  return { ...(stdout.length > 0 && { stdout }), ...(stderr.length > 0 && { stderr }) };
}

// The model's judgment on the step that failed, when a model judged it.
function failingExplanation(steps: readonly Step[]): string | undefined {
  return steps.findLast((step) => step.status !== 'passed' && step.explanation)?.explanation;
}

function stepCategory(kind: Step['kind']): string {
  return kind === 'assertion' ? 'expect' : `e2e:${kind}`;
}

function stepTitle(step: Step): string {
  return step.label ? `${step.api} ${step.label}` : step.api;
}

// What mapping one result reads from its run.
type RunContext = Pick<Run, 'serialGroups' | 'startedAt'>;

function attemptViews(result: Result, run: RunContext): AttemptView[] {
  if (result.serialGroupId !== undefined) {
    const group = run.serialGroups.find((candidate) => candidate.id === result.serialGroupId);
    const views: AttemptView[] = [];
    for (const groupAttempt of group?.attempts ?? []) {
      const member = groupAttempt.members.find((candidate) => candidate.testId === result.testId);
      if (!member) continue;
      // A group attempt records one trace or video for all its members; it goes
      // to the member that failed, or to the last one when the attempt passed.
      const failing = groupAttempt.members.find(
        (candidate) => candidate.status !== 'passed' && candidate.status !== 'skipped'
      );
      const owner = failing ?? groupAttempt.members[groupAttempt.members.length - 1];
      views.push({
        index: groupAttempt.index,
        status: member.status,
        startedAt: member.startedAt,
        durationMs: member.durationMs,
        steps: member.steps,
        artifacts: owner === member ? groupAttempt.artifacts : [],
        error: member.error,
        failure: member.failure,
        appLog: appLogOf(member),
        skipReason: member.skip?.reason,
      });
    }
    if (views.length > 0) return views;
  }

  if (result.attempts.length > 0) {
    return result.attempts.map((attempt) => ({
      index: attempt.index,
      status: attempt.status,
      startedAt: attempt.startedAt,
      durationMs: attempt.durationMs,
      steps: attempt.steps,
      artifacts: attempt.artifacts,
      error: attempt.error,
      failure: attempt.failure,
      appLog: appLogOf(attempt),
      skipReason: attempt.skip?.reason,
    }));
  }

  // A test skipped before it started (test.skip, a failed setup) has no attempt;
  // the server still needs a begin and an end to count it.
  return [
    {
      index: 0,
      status: ATTEMPT_FALLBACK[result.status],
      startedAt: run.startedAt,
      durationMs: 0,
      steps: [],
      artifacts: [],
      skipReason: result.skip?.reason,
    },
  ];
}

function finalOutcome(status: Result['status']): TestEndEvent['outcome'] {
  if (status === 'passed') return 'expected';
  if (status === 'flaky') return 'flaky';
  if (status === 'skipped') return 'skipped';
  return 'unexpected';
}

/**
 * e2e's live `test-finished` result, as far as mapping reads it: the identity
 * nests under `test` and `target`, and the declaration's file is absolute.
 */
export interface LiveResult {
  test: Pick<Result, 'kind' | 'declarationIndex' | 'titlePath' | 'file' | 'source' | 'tags'> & { id: string };
  target: { name: string; platform: string };
  agent: string;
  repeat: number;
  selected: boolean;
  status: Result['status'];
  skip?: Result['skip'];
  serialGroupId?: string;
  attempts: Result['attempts'];
}

/** A live result in the final report's shape, so a streamed test maps like a reported one. */
export function resultFromEvent(live: LiveResult, projectRoot: string): Result {
  const { test } = live;
  const file = relative(projectRoot, test.source.file).split(sep).join('/');
  return {
    id: '',
    testId: test.id,
    kind: test.kind,
    declarationIndex: test.declarationIndex,
    titlePath: test.titlePath,
    file: test.file,
    source: { ...test.source, file },
    targetId: live.target.name,
    platform: live.target.platform,
    agent: live.agent,
    repeat: live.repeat,
    tags: test.tags,
    selected: live.selected,
    status: live.status,
    ...(live.skip && { skip: live.skip }),
    ...(live.serialGroupId !== undefined && { serialGroupId: live.serialGroupId }),
    attempts: live.attempts,
  } as Result;
}

/** e2e's live `test-started` event, as far as a begin needs it. */
export interface LiveStart {
  testId: string;
  file: string;
  target: string;
  agent: string;
  repeat: number;
  at: string;
}

/**
 * A test's first attempt, begun as it starts so the dashboard lists it as
 * running. e2e names the file and the titles (its id percent-encodes each
 * title, `:` included, so `::` splits them), not yet the line, tags or
 * retries; the begin sent when the test finishes fills those in, on the same row.
 */
export function beginFromStart(start: LiveStart, slot = 0): Unstamped<TestBeginEvent> {
  const titlePath = start.testId.split('::').slice(1).map(decodeURIComponent);
  const result = {
    testId: start.testId,
    titlePath,
    file: start.file,
    source: { file: start.file, line: 0, column: 0 },
    targetId: start.target,
    agent: start.agent,
    repeat: start.repeat,
    tags: [],
    selected: true,
    status: 'passed',
    attempts: [{ index: 0, status: 'passed', startedAt: start.at, durationMs: 0, steps: [], artifacts: [] }],
  } as unknown as Result;
  return planTest(result, { serialGroups: [], startedAt: start.at }, slot).attempts[0]!.begin;
}

// `slot` is the worker line the dashboard groups the test under; e2e names no worker.
export function planTest(result: Result, run: RunContext, slot = 0): PlannedTest {
  const testId = wireTestId(result);
  const title = result.titlePath[result.titlePath.length - 1] ?? '';
  const titlePath = ['', result.targetId, result.file, ...result.titlePath];
  const location = toLocation(result.source, result.file);
  const describeTitle = result.titlePath.length > 1 ? result.titlePath[result.titlePath.length - 2] : undefined;
  const parentSuite: TestBeginEvent['parentSuite'] =
    describeTitle === undefined
      ? { title: result.file, type: 'file', location: { file: result.file, line: 0, column: 0 } }
      : { title: describeTitle, type: 'describe', location: { file: result.file, line: 0, column: 0 } };

  const views = attemptViews(result, run);
  const lastIndex = views.length - 1;

  const attempts = views.map((view, position): PlannedAttempt => {
    const startTime = Date.parse(view.startedAt);
    const isFinal = position === lastIndex;
    const annotations =
      view.status === 'skipped' ? [{ type: 'skip', ...(view.skipReason && { description: view.skipReason }) }] : [];
    const shared = { testId, retry: position, workerIndex: slot, parallelIndex: slot };

    const steps: PlannedAttempt['steps'] = [];
    for (const step of view.steps) {
      const stepStart = Date.parse(step.startedAt);
      const stepTitlePath = [stepTitle(step)];
      steps.push({
        type: 'step:begin',
        timestamp: stepStart,
        ...shared,
        stepId: step.id,
        title: stepTitle(step),
        titlePath: stepTitlePath,
        category: stepCategory(step.kind),
        startTime: stepStart,
        annotations: [],
        ...(step.source && { location: toLocation(step.source, result.file) }),
      });
      steps.push({
        type: 'step:end',
        timestamp: stepStart + step.durationMs,
        ...shared,
        stepId: step.id,
        title: stepTitle(step),
        titlePath: stepTitlePath,
        duration: step.durationMs,
        status: step.status === 'passed' ? 'passed' : 'failed',
        childSteps: { count: 0, steps: [] },
        attachments: [],
        annotations: [],
        ...(step.error && { error: toWireError(step.error, step.explanation) }),
      });
    }

    const passedSteps = view.steps.filter((step) => step.status === 'passed').length;

    return {
      begin: {
        type: 'test:begin',
        timestamp: startTime,
        ...shared,
        title,
        titlePath,
        location,
        tags: [...result.tags],
        expectedStatus: view.status === 'skipped' ? 'skipped' : 'passed',
        timeout: 0,
        // The report does not carry the configured retry count; the attempts that
        // ran bound it, which is what the server needs to tell a final attempt apart.
        retries: lastIndex,
        annotations,
        repeatEachIndex: result.repeat,
        parentSuite,
        startTime,
      },
      steps,
      end: {
        type: 'test:end',
        timestamp: startTime + view.durationMs,
        ...shared,
        status: ATTEMPT_STATUS[view.status],
        outcome: isFinal ? finalOutcome(result.status) : 'unexpected',
        duration: view.durationMs,
        annotations,
        errors: view.error ? [toWireError(view.error, failingExplanation(view.steps), view.failure)] : [],
        steps: { total: view.steps.length, passed: passedSteps, failed: view.steps.length - passedSteps },
        attachments: [],
        ...appConsole(view),
      },
      artifacts: [...view.artifacts],
    };
  });

  return {
    testId,
    identity: { testId: result.testId, targetId: result.targetId, agent: result.agent, repeat: result.repeat },
    attempts,
  };
}

function buildSkeleton(results: readonly Result[]): Skeleton {
  const projects = new Map<string, SkeletonSuite>();

  const child = (parent: SkeletonSuite, title: string, create: () => SkeletonSuite): SkeletonSuite => {
    let suite = parent.suites.find((candidate) => candidate.title === title);
    if (!suite) {
      suite = create();
      parent.suites.push(suite);
    }
    return suite;
  };

  for (const result of results) {
    let project = projects.get(result.targetId);
    if (!project) {
      project = { title: result.targetId, type: 'project', tests: [], suites: [] };
      projects.set(result.targetId, project);
    }

    let suite = child(project, result.file, () => ({
      title: result.file,
      type: 'file',
      file: result.file,
      tests: [],
      suites: [],
    }));
    for (const describeTitle of result.titlePath.slice(0, -1)) {
      suite = child(suite, describeTitle, () => ({
        title: describeTitle,
        type: 'describe',
        file: result.file,
        tests: [],
        suites: [],
      }));
    }

    suite.tests.push({
      testId: wireTestId(result),
      title: result.titlePath[result.titlePath.length - 1] ?? '',
      location: toLocation(result.source, result.file),
      expectedStatus: result.status === 'skipped' ? 'skipped' : 'passed',
    });
  }

  return { totalTests: results.length, suites: [...projects.values()] };
}

/** A traced test's page and the attempt it belongs to: the last, the one a reader opens. */
export interface TracePage {
  testId: string;
  retry: number;
  /** From the project root, as e2e's run-finished event gives it. */
  path: string;
}

// e2e writes trace pages only when the whole run finishes, after each test's
// test:end went out, so a page reaches its attempt as a late test:attachments.
export function tracePages(
  report: Report,
  tests: readonly PlannedTest[],
  traces: Readonly<Record<string, string>>
): TracePage[] {
  const planned = new Map(tests.map((test) => [test.testId, test]));
  const pages: TracePage[] = [];
  for (const result of report.run.results) {
    const path = traces[result.id];
    const test = path === undefined ? undefined : planned.get(wireTestId(result));
    if (path !== undefined && test && test.attempts.length > 0)
      pages.push({ testId: test.testId, retry: test.attempts.length - 1, path });
  }
  return pages;
}

/** Plans every wire event of one finished run, in the order the server expects them. */
// Cap on run:end's retriedTests map, as in the Playwright reporter.
const MAX_RETRIED_TESTS = 500;

// Counted from e2e's report, never from what was delivered: a count below the
// truth would lower the server's target and hide tests that never arrived.
function completeness(tests: readonly PlannedTest[]) {
  const retried = tests.filter((test) => test.attempts.length > 1);
  return {
    executedTests: tests.length,
    executedAttempts: tests.reduce((sum, test) => sum + test.attempts.length, 0),
    retriedTests: Object.fromEntries(
      retried.slice(0, MAX_RETRIED_TESTS).map((test) => [test.testId, test.attempts.length])
    ),
    ...(retried.length > MAX_RETRIED_TESTS && { retriedTestsTruncated: true as const }),
  };
}

export function planRun(report: Report): RunPlan {
  const { run } = report;
  const startTime = Date.parse(run.startedAt);
  const finishTime = Date.parse(run.finishedAt);
  // An unselected result is a test the run's filters left out; it is not part of this run.
  const results = run.results.filter((result) => result.selected);
  const tests = results.map((result) => planTest(result, run));

  return {
    runId: run.id,
    startTime,
    frameworkVersion: run.runner.version,
    targets: run.targets.map((target) => target.id),
    skeleton: buildSkeleton(results),
    tests,
    runErrors: run.errors.map((error) => ({
      type: 'run:error',
      timestamp: finishTime,
      message: `${error.code}: ${error.message}`,
    })),
    end: {
      type: 'run:end',
      timestamp: finishTime,
      status: RUN_STATUS[run.status],
      duration: finishTime - startTime,
      startTime,
      ...completeness(tests),
    },
  };
}
