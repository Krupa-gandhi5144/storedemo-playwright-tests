// Builds the code frame and stack the TestDino UI shows under a failure. The
// e2e report carries only the failing line's position, so the frame is read
// from the test file.
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { Location, PlannedTest, WireError } from './wire.ts';

const CONTEXT_BEFORE = 2;
const CONTEXT_AFTER = 3;

/** A code frame in the layout the dashboard parses: `> 30 | code`, then a caret line. */
export function codeFrame(source: string, line: number, column: number): string {
  const lines = source.split('\n');
  if (line < 1 || line > lines.length) return '';
  const first = Math.max(1, line - CONTEXT_BEFORE);
  const last = Math.min(lines.length, line + CONTEXT_AFTER);
  const width = String(last).length;

  const frame: string[] = [];
  for (let current = first; current <= last; current++) {
    const marker = current === line ? '>' : ' ';
    frame.push(`${marker} ${String(current).padStart(width)} | ${lines[current - 1] ?? ''}`);
    if (current === line) frame.push(`  ${' '.repeat(width)} | ${' '.repeat(Math.max(0, column - 1))}^`);
  }
  return frame.join('\n');
}

/** Reads test files once each and frames the lines errors point at. */
export function createFramer(projectRoot: string) {
  const files = new Map<string, Promise<string | undefined>>();
  const read = (file: string) => {
    let pending = files.get(file);
    if (!pending) {
      // A file that moved or was deleted since the run leaves the error without a frame.
      pending = readFile(join(projectRoot, file), 'utf8').catch(() => undefined);
      files.set(file, pending);
    }
    return pending;
  };

  return async (location: Location | undefined): Promise<string> => {
    if (!location || location.line < 1) return '';
    const source = await read(location.file);
    return source === undefined ? '' : codeFrame(source, location.line, location.column);
  };
}

export function stackOf(message: string, location: Location | undefined): string {
  return location ? `${message}\n    at ${location.file}:${location.line}:${location.column}` : message;
}

// Gives each failure the code frame and stack the dashboard renders.
export async function frameErrors(tests: readonly PlannedTest[], projectRoot: string): Promise<void> {
  const frame = createFramer(projectRoot);
  const enrich = async (error: WireError) => {
    error.snippet = await frame(error.location);
    error.stack = stackOf(error.stack || error.message, error.location);
  };
  for (const test of tests) {
    for (const attempt of test.attempts) {
      for (const error of attempt.end.errors) await enrich(error);
      for (const step of attempt.steps) {
        if (step.type === 'step:end' && step.error) await enrich(step.error);
      }
    }
  }
}
