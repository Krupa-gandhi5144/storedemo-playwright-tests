// Delivers wire events over the channel the server offers: Kafka when it
// advertises a broker (the hosted service), else its HTTP endpoint (local dev).
import { Kafka, Partitioners, logLevel, type Producer } from 'kafkajs';
import type { AuthResult, TestdinoClient } from './client.ts';
import type { WireEvent } from './wire.ts';

const KAFKA_BATCH_EVENTS = 500;

// kafkajs 2.2.4 schedules a timer with a negative delay while its request queue
// drains, and Node prints a TimeoutNegativeWarning for it. The warning is
// cosmetic; it is dropped only when it comes from kafkajs and only while the
// producer is open.
function silenceKafkaTimerWarning(): () => void {
  const original = process.emitWarning;
  const forward = original.bind(process) as (warning: string | Error, ...rest: unknown[]) => void;
  const patched = ((warning: string | Error, ...rest: unknown[]) => {
    const type = typeof rest[0] === 'string' ? rest[0] : (rest[0] as { type?: string } | undefined)?.type;
    const name = warning instanceof Error ? warning.name : type;
    if (name === 'TimeoutNegativeWarning' && (new Error().stack ?? '').includes('kafkajs')) return;
    forward(warning, ...rest);
  }) as typeof process.emitWarning;
  process.emitWarning = patched;
  return () => {
    // Something else may have patched on top since; then leave the chain alone.
    if (process.emitWarning === patched) process.emitWarning = original;
  };
}

export interface Delivery {
  readonly channel: 'kafka' | 'http';
  send(events: readonly WireEvent[]): Promise<void>;
  close(): Promise<void>;
}

async function connectKafka(kafka: NonNullable<AuthResult['kafka']>, runId: string): Promise<Producer | undefined> {
  if (!kafka.channel || kafka.brokers.length === 0) return undefined;
  const producer = new Kafka({
    clientId: `testdino-e2e-reporter-${runId.slice(0, 8)}`,
    brokers: kafka.brokers,
    connectionTimeout: 10_000,
    requestTimeout: 30_000,
    // One connection attempt: the reporter has a one-minute budget and an HTTP fallback.
    retry: { retries: 1 },
    logLevel: logLevel.NOTHING,
    ...(kafka.sasl && {
      // The server sends the mechanism uppercase; kafkajs wants it lowercase.
      sasl: { ...kafka.sasl, mechanism: kafka.sasl.mechanism.toLowerCase() } as never,
    }),
    ...(kafka.ssl !== undefined && { ssl: kafka.ssl }),
  }).producer({ createPartitioner: Partitioners.DefaultPartitioner });

  try {
    await producer.connect();
    return producer;
  } catch {
    await producer.disconnect().catch(() => {});
    return undefined;
  }
}

/** Opens the best channel the auth response offers; undefined when it offers none that works. */
export async function openDelivery(
  client: TestdinoClient,
  auth: AuthResult,
  serverUrl: string,
  runId: string
): Promise<Delivery | undefined> {
  const httpUrl = auth.httpFallback ? new URL(auth.httpFallback, serverUrl).toString() : undefined;
  const sendHttp = httpUrl ? (events: readonly WireEvent[]) => client.sendEvents(httpUrl, events) : undefined;

  const restoreWarnings = auth.kafka ? silenceKafkaTimerWarning() : () => {};
  const producer = auth.kafka ? await connectKafka(auth.kafka, runId) : undefined;
  if (!producer) restoreWarnings();
  if (producer && auth.kafka?.channel) {
    const topic = auth.kafka.channel;
    return {
      channel: 'kafka',
      async send(events) {
        try {
          for (let start = 0; start < events.length; start += KAFKA_BATCH_EVENTS) {
            const messages = events
              .slice(start, start + KAFKA_BATCH_EVENTS)
              // Keyed by run so every event of a run lands on one partition, in order.
              .map((event) => ({ key: event.runId, value: JSON.stringify(event) }));
            await producer.send({ topic, acks: 1, messages });
          }
        } catch (error) {
          // The server upserts, so resending a batch Kafka half-accepted is safe.
          if (!sendHttp) throw error;
          await sendHttp(events);
        }
      },
      async close() {
        await producer.disconnect().catch(() => {});
        restoreWarnings();
      },
    };
  }

  if (!sendHttp) return undefined;
  return { channel: 'http', send: sendHttp, close: async () => {} };
}
