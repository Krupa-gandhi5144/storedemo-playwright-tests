// Tells someone running an older @testdino/e2e that a newer one is out, as
// @testdino/playwright does: a 24 h cache, a short request, never in the way of the run.
import { readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const REGISTRY_URL = 'https://registry.npmjs.org/@testdino%2fe2e';
const CHECK_TIMEOUT_MS = 1_500;
// Once a day, not once per run, shard and CI job.
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const CACHE_FILE = join(tmpdir(), 'testdino-e2e-update-check.json');
// When the run finishes first, the notice is worth only a brief wait.
const SETTLE_GRACE_MS = 150;

export function compareVersions(a: string, b: string): number {
  const parse = (version: string) =>
    version
      .replace(/^v/, '')
      .split(/[+-]/)[0]!
      .split('.')
      .map((part) => Number.parseInt(part, 10));
  const left = parse(a);
  const right = parse(b);
  if (left.some(Number.isNaN) || right.some(Number.isNaN)) return 0;
  for (let i = 0; i < 3; i++) {
    const diff = (left[i] ?? 0) - (right[i] ?? 0);
    if (diff !== 0) return diff > 0 ? 1 : -1;
  }
  return 0;
}

// A prerelease (1.2.0-beta.1) is never told it is behind the release it precedes.
const isPrerelease = (version: string) => version.includes('-');

function readCache(file: string): string | undefined {
  try {
    const { checkedAt, latest } = JSON.parse(readFileSync(file, 'utf8')) as { checkedAt?: unknown; latest?: unknown };
    if (typeof checkedAt !== 'number' || typeof latest !== 'string') return undefined;
    // A clock moved backwards would otherwise keep a stale entry fresh forever.
    const age = Date.now() - checkedAt;
    return age >= 0 && age < CACHE_TTL_MS ? latest : undefined;
  } catch {
    return undefined;
  }
}

function writeCache(file: string, latest: string): void {
  try {
    writeFileSync(file, JSON.stringify({ checkedAt: Date.now(), latest }));
  } catch {
    // An unwritable cache only means checking again next run.
  }
}

async function fetchLatest(signal: AbortSignal): Promise<string | undefined> {
  try {
    const response = await fetch(REGISTRY_URL, {
      headers: { accept: 'application/vnd.npm.install-v1+json' },
      signal: AbortSignal.any([signal, AbortSignal.timeout(CHECK_TIMEOUT_MS)]),
    });
    if (!response.ok) return undefined;
    const latest = ((await response.json()) as { 'dist-tags'?: { latest?: unknown } })['dist-tags']?.latest;
    return typeof latest === 'string' ? latest : undefined;
  } catch {
    return undefined;
  }
}

export interface UpdateCheck {
  /** The newer version, if any; settles within a brief grace and cancels a request still running. */
  result(): Promise<string | undefined>;
}

export function startUpdateCheck(
  current: string,
  { cacheFile = CACHE_FILE, latest: lookUp = fetchLatest } = {}
): UpdateCheck {
  const abort = new AbortController();
  const pending = (async () => {
    if (isPrerelease(current)) return undefined;
    const cached = readCache(cacheFile);
    const latest = cached ?? (await lookUp(abort.signal));
    if (!latest || isPrerelease(latest)) return undefined;
    if (!cached) writeCache(cacheFile, latest);
    return compareVersions(latest, current) > 0 ? latest : undefined;
  })().catch(() => undefined);

  return {
    async result() {
      let timer: ReturnType<typeof setTimeout> | undefined;
      const grace = new Promise<undefined>(
        (resolve) => (timer = setTimeout(() => resolve(undefined), SETTLE_GRACE_MS))
      );
      try {
        return await Promise.race([pending, grace]);
      } finally {
        clearTimeout(timer);
        // A request still running would hold the process open after the run.
        abort.abort();
      }
    },
  };
}
