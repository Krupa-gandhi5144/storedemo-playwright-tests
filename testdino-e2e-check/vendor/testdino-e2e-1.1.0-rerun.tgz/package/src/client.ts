// HTTP client for the TestDino reporter API: authenticate, send event batches,
// and upload artifacts through server-minted upload URLs.
import type { WireEvent } from './wire.ts';

export { DEFAULT_SERVER_URL } from './server.js';

// The server caps one POST at 1000 events and 5 MiB; stay under both.
const MAX_BATCH_EVENTS = 500;
const MAX_BATCH_BYTES = 3 * 1024 * 1024;

export interface AuthResult {
  projectId: string;
  kafka?: {
    brokers: string[];
    channel?: string;
    sasl?: { mechanism: string; username: string; password: string };
    ssl?: boolean;
  };
  httpFallback?: string;
  overLimit?: boolean;
}

export interface UploadSlot {
  blobKey: string;
  uploadUrl: string;
}

export class TestdinoApiError extends Error {
  readonly status: number;

  constructor(action: string, status: number, detail: string) {
    super(`${action} failed with HTTP ${status}${detail ? `: ${detail}` : ''}`);
    this.name = 'TestdinoApiError';
    this.status = status;
  }
}

async function errorDetail(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as { message?: unknown; error?: { message?: unknown } | unknown };
    if (typeof body.message === 'string') return body.message;
    if (typeof body.error === 'object' && body.error !== null) {
      const nested = (body.error as { message?: unknown }).message;
      if (typeof nested === 'string') return nested;
    }
    if (typeof body.error === 'string') return body.error;
  } catch {
    // A non-JSON error body carries nothing worth showing.
  }
  return '';
}

export class TestdinoClient {
  private readonly token: string;
  private readonly serverUrl: string;
  private readonly signal: AbortSignal;

  constructor(options: { token: string; serverUrl: string; signal: AbortSignal }) {
    this.token = options.token;
    this.serverUrl = options.serverUrl.replace(/\/+$/, '');
    this.signal = options.signal;
  }

  private async post(url: string, action: string, body?: unknown, signal?: AbortSignal): Promise<Response> {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${this.token}` },
      ...(body !== undefined && { body: JSON.stringify(body) }),
      signal: signal ? AbortSignal.any([this.signal, signal]) : this.signal,
    });
    if (!response.ok) throw new TestdinoApiError(action, response.status, await errorDetail(response));
    return response;
  }

  async authenticate(): Promise<AuthResult> {
    const response = await this.post(`${this.serverUrl}/api/v1/reporter/auth`, 'authentication');
    return (await response.json()) as AuthResult;
  }

  async sendEvents(url: string, events: readonly WireEvent[]): Promise<void> {
    let batch: WireEvent[] = [];
    let bytes = 0;
    const flush = async () => {
      if (batch.length === 0) return;
      await this.post(url, 'event delivery', { events: batch });
      batch = [];
      bytes = 0;
    };

    for (const event of events) {
      const size = Buffer.byteLength(JSON.stringify(event));
      if (batch.length >= MAX_BATCH_EVENTS || (batch.length > 0 && bytes + size > MAX_BATCH_BYTES)) await flush();
      batch.push(event);
      bytes += size;
    }
    await flush();
  }

  /** Mints one upload URL per file; the response is index-aligned with the request. */
  async requestUploadSlots(
    runId: string,
    files: readonly { name: string; testId: string; contentType: string; sizeBytes: number }[],
    signal?: AbortSignal
  ): Promise<UploadSlot[]> {
    const response = await this.post(
      `${this.serverUrl}/api/v1/reporter/runs/${encodeURIComponent(runId)}/artifacts/upload-token`,
      'upload-token request',
      {
        files: files.map((file) => ({
          name: file.name,
          test_id: file.testId,
          content_type: file.contentType,
          size_bytes: file.sizeBytes,
        })),
      },
      signal
    );
    const body = (await response.json()) as { uploads?: { blob_key: string; upload_url: string }[] };
    const uploads = body.uploads ?? [];
    if (uploads.length !== files.length) {
      throw new Error(`upload-token response has ${uploads.length} slots for ${files.length} files`);
    }
    return uploads.map((upload) => ({ blobKey: upload.blob_key, uploadUrl: upload.upload_url }));
  }

  async uploadFile(
    uploadUrl: string,
    bytes: Uint8Array<ArrayBuffer>,
    contentType: string,
    signal: AbortSignal
  ): Promise<void> {
    const response = await fetch(uploadUrl, {
      method: 'PUT',
      headers: { 'content-type': contentType, 'x-ms-blob-type': 'BlockBlob' },
      body: bytes,
      signal: AbortSignal.any([this.signal, signal]),
    });
    if (!response.ok) throw new TestdinoApiError('artifact upload', response.status, '');
  }

  /** The dashboard URL of the run, once the server has recorded it; undefined until then. */
  async resolveRunLink(runId: string): Promise<string | undefined> {
    const response = await fetch(`${this.serverUrl}/api/v1/reporter/runs/${encodeURIComponent(runId)}/link`, {
      headers: { authorization: `Bearer ${this.token}` },
      signal: this.signal,
    });
    if (!response.ok) return undefined;
    const body = (await response.json()) as { url?: unknown };
    return typeof body.url === 'string' && body.url.length > 0 ? body.url : undefined;
  }
}
