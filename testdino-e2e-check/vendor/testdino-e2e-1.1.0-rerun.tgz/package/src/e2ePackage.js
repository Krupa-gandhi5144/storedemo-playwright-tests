// @ts-check
// The e2e the project installed. Plain JavaScript so the `testdino-e2e` bin,
// which runs untranspiled from node_modules, shares it with the reporter.
import { existsSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';

/**
 * Its folder and package.json. Its `exports` hide package.json, so walk up
 * from its entry. Throws when the project has no e2e installed.
 * @param {string} cwd
 * @returns {{ dir: string; version: string; bin: string }}
 */
export function e2ePackage(cwd) {
  let dir = path.dirname(createRequire(path.join(cwd, 'package.json')).resolve('e2e'));
  for (; dir !== path.dirname(dir); dir = path.dirname(dir)) {
    const manifest = path.join(dir, 'package.json');
    if (!existsSync(manifest)) continue;
    const { name, version, bin } = JSON.parse(readFileSync(manifest, 'utf8'));
    if (name === 'e2e') return { dir, version, bin: path.join(dir, typeof bin === 'string' ? bin : bin.e2e) };
  }
  throw new Error('no package.json');
}
