import { readFile, stat } from 'node:fs/promises';
import { basename, extname } from 'node:path';
import type { TestdinoClient } from './client.ts';
import type { WireAttachment } from './wire.ts';

const ALLOWED_EXTENSIONS = new Set(['png', 'jpeg', 'jpg', 'webm', 'mp4', 'zip', 'json', 'txt', 'md']);
// A server older than MP4 support refuses a whole slot request holding one, so
// MP4s ask on their own: there only the videos are refused, never a screenshot.
const OWN_REQUEST_EXTENSIONS = new Set(['mp4']);
const MAX_ARTIFACT_BYTES = 50 * 1024 * 1024;
export const UPLOAD_CONCURRENCY = 4;
// data-handler's cap on files per upload-token request.
const UPLOAD_SLOTS_PER_REQUEST = 100;

export interface UploadFile {
  testId: string;
  name: string;
  contentType: string;
  /** Absolute; none when the file never appeared, was withheld, or lives on a hosted service. */
  path: string | undefined;
}

// One upload's longest wait while the run is still going and no deadline is set.
const MAX_UPLOAD_MS = 60_000;

// Slots are asked for in chunks of the server's per-request cap, and a file is
// read only when its turn to upload comes, so a run ending with thousands of
// files holds a few in memory at a time. Past `deadline` (epoch ms) no slot is
// asked for and no file starts, and every request is cut off at it, so what comes
// after the uploads is never delayed: those files are sent unavailable. `stop`
// cuts off requests already running when a deadline is set later.
export async function uploadFiles(
  client: Pick<TestdinoClient, 'requestUploadSlots' | 'uploadFile'>,
  runId: string,
  files: readonly UploadFile[],
  deadline: () => number = () => Infinity,
  stop?: AbortSignal
): Promise<WireAttachment[]> {
  const timeLeft = () => deadline() - Date.now();
  const bounded = () => {
    const timeout = AbortSignal.timeout(Math.max(0, Math.min(timeLeft(), MAX_UPLOAD_MS)));
    return stop ? AbortSignal.any([timeout, stop]) : timeout;
  };
  const attachments = files.map((file): WireAttachment => ({ name: file.name, contentType: file.contentType }));
  const ready: { attachment: WireAttachment; file: UploadFile & { path: string }; sizeBytes: number }[] = [];
  for (const [index, file] of files.entries()) {
    const attachment = attachments[index]!;
    const extension = file.path ? extname(file.path).slice(1).toLowerCase() : '';
    if (!file.path || !ALLOWED_EXTENSIONS.has(extension)) {
      attachment.unavailable = true;
      continue;
    }
    try {
      const { size } = await stat(file.path);
      if (size > MAX_ARTIFACT_BYTES) attachment.unavailable = true;
      else ready.push({ attachment, file: { ...file, path: file.path }, sizeBytes: size });
    } catch {
      attachment.unavailable = true;
    }
  }

  const ownRequest = (entry: (typeof ready)[number]) =>
    OWN_REQUEST_EXTENSIONS.has(extname(entry.file.path).slice(1).toLowerCase());
  const chunks = [ready.filter((entry) => !ownRequest(entry)), ready.filter(ownRequest)].flatMap((group) =>
    Array.from({ length: Math.ceil(group.length / UPLOAD_SLOTS_PER_REQUEST) }, (_, i) =>
      group.slice(i * UPLOAD_SLOTS_PER_REQUEST, (i + 1) * UPLOAD_SLOTS_PER_REQUEST)
    )
  );
  for (const chunk of chunks) {
    if (timeLeft() <= 0) {
      for (const { attachment } of chunk) attachment.unavailable = true;
      continue;
    }
    try {
      const slots = await client.requestUploadSlots(
        runId,
        chunk.map(({ file, sizeBytes }) => ({
          name: basename(file.path),
          testId: file.testId,
          contentType: file.contentType,
          sizeBytes,
        })),
        bounded()
      );
      const uploads = chunk.map((entry, index) => ({ ...entry, slot: slots[index]! }));
      await inPool(uploads, UPLOAD_CONCURRENCY, async ({ attachment, file, slot }) => {
        if (timeLeft() <= 0 || stop?.aborted) {
          attachment.unavailable = true;
          return;
        }
        try {
          await client.uploadFile(slot.uploadUrl, await readFile(file.path), file.contentType, bounded());
          attachment.blobKey = slot.blobKey;
        } catch {
          attachment.unavailable = true;
        }
      });
    } catch {
      for (const { attachment } of chunk) attachment.unavailable = true;
    }
  }
  return attachments;
}

export async function inPool<Item>(
  items: readonly Item[],
  limit: number,
  work: (item: Item) => Promise<void>
): Promise<void> {
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const item = items[next++]!;
      await work(item);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
}
