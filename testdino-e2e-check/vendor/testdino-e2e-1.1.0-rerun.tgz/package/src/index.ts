// TestDino reporter for e2e: sends a run to TestDino in the wire protocol the
// Playwright reporter speaks, so the run shows up on the dashboard.
//
// It streams: run:begin once e2e has planned the run, then each test as it
// finishes. e2e's plan names how many tests run, not which, so the skeleton
// carries only the total; the server creates each test when it first arrives.
// The final report (onRunFinished) sends what the stream did not, and is the
// whole upload when the stream never started.
import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { basename, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Reporter } from 'e2e';
import { type AuthResult, DEFAULT_SERVER_URL, TestdinoClient } from './client.ts';
import { e2ePackage } from './e2ePackage.js';
import { openDelivery, type Delivery } from './delivery.ts';
import { collectCI, collectGit, collectSystem, REPORTER_VERSION, resolveActorIsAuthor } from './metadata.ts';
import { startUpdateCheck, type UpdateCheck } from './update.ts';
import {
  decideTestControls,
  fetchQuarantineList,
  type FinishedTest,
  type QuarantineFetchOutcome,
} from './test-controls.ts';
import { frameErrors } from './source.ts';
import { type Heartbeat, startHeartbeat } from './heartbeat.ts';
import { inPool, UPLOAD_CONCURRENCY, uploadFiles } from './upload.ts';
import {
  beginFromStart,
  type LiveResult,
  type LiveStart,
  parseSlice,
  planRun,
  planTest,
  resultFromEvent,
  shardFromArgv,
  type PlannedAttempt,
  type TestAttachmentsEvent,
  type TracePage,
  tracePages,
  type PlannedTest,
  type RunPlan,
  type RunSelectionReport,
  type RunBeginEvent,
  type Skeleton,
  type WireAttachment,
  type WireEvent,
  wireTestId,
} from './wire.ts';

export interface TestdinoOptions {
  /** Project API key; defaults to TESTDINO_TOKEN. */
  token?: string;
  /** Reporter API origin; defaults to TESTDINO_SERVER_URL, then the hosted service. */
  serverUrl?: string;
  /** Groups the shards of one run (`--shard`) into one TestDino run; defaults to TESTDINO_CI_RUN_ID. */
  ciRunId?: string;
  /**
   * Split position (`"2/4"`) when the suite is divided across jobs by hand, each
   * job running its own files; defaults to TESTDINO_SPLIT. Needs `splitId`.
   */
  split?: string;
  /** Groups the splits of one run; defaults to TESTDINO_SPLIT_ID. */
  splitId?: string;
  /** Run-level labels shown on the run. */
  tags?: string[];
  /** Upload screenshots, traces, and videos; on by default. */
  artifacts?: boolean;
  /** Print what the reporter does to stderr; defaults to TESTDINO_DEBUG (`1` or `true`). */
  debug?: boolean;
}

function debugLog(options: TestdinoOptions, message: string): void {
  const env = process.env.TESTDINO_DEBUG;
  if (options.debug ?? (env === '1' || env === 'true')) process.stderr.write(`testdino: ${message}\n`);
}

const errorText = (error: unknown) => (error instanceof Error ? error.message : String(error));

// Mirrors the server's artifact allowlist and size cap; a file outside either
// would fail the whole upload-token batch.
// e2e gives a reporter one minute; uploads stop early enough to still deliver the events.
const UPLOAD_BUDGET_MS = 40_000;

// Console output kept per run; past this the oldest tests keep theirs and the rest is dropped.
const MAX_OUTPUT_BYTES = 2 * 1024 * 1024;

const LINK_ATTEMPTS = 6;
const LINK_RETRY_MS = 500;

const LABEL = 'TestDino';

interface CapturedOutput {
  testId: string;
  targetId: string;
  agent: string;
  repeat: number;
  stream: 'stdout' | 'stderr';
  text: string;
  at: number;
}

// e2e reports output per test, not per attempt; the write's time picks the attempt.
function attachOutput(tests: readonly PlannedTest[], output: readonly CapturedOutput[]): void {
  for (const chunk of output) {
    const test = tests.find(
      ({ identity }) =>
        identity.testId === chunk.testId &&
        identity.targetId === chunk.targetId &&
        identity.agent === chunk.agent &&
        identity.repeat === chunk.repeat
    );
    if (!test) continue;
    const started = test.attempts.filter((attempt) => attempt.begin.startTime <= chunk.at);
    const attempt = started[started.length - 1] ?? test.attempts[0];
    if (!attempt) continue;
    (attempt.end[chunk.stream] ??= []).push(chunk.text);
  }
}

// The visual comparison view pairs Playwright's `<name>-expected|actual|diff.png`,
// the names of a failed toHaveScreenshot's images (e2e adds -2 when a name repeats).
const COMPARISON_IMAGE = /^(.+)-(expected|actual|diff)(-\d+)?\.png$/;

// Only a complete pair: the view hides a lone image, and a screen that never held
// still has an actual and a diff but no expected.
function attachmentName(attempt: PlannedAttempt, artifact: PlannedAttempt['artifacts'][number]): string {
  const match = artifact.kind === 'screenshot' && artifact.path ? COMPARISON_IMAGE.exec(basename(artifact.path)) : null;
  if (!match) return artifact.kind;
  const [, stem, role, repeat = ''] = match;
  const attached = (name: string) =>
    attempt.artifacts.some((other) => other.path && basename(other.path) === `${stem}-${name}${repeat}.png`);
  return attached('expected') && attached('actual') ? `${stem}${repeat}-${role}.png` : artifact.kind;
}

function uploadAttempt(
  client: TestdinoClient,
  runId: string,
  artifactsRoot: string,
  testId: string,
  attempt: PlannedAttempt,
  deadline: () => number,
  stop?: AbortSignal
): Promise<WireAttachment[]> {
  return uploadFiles(
    client,
    runId,
    attempt.artifacts.map((artifact) => ({
      testId,
      name: attachmentName(attempt, artifact),
      contentType: artifact.mediaType,
      path: artifact.path ? join(artifactsRoot, artifact.path) : undefined,
    })),
    deadline,
    stop
  );
}

// Never named "trace": the dashboard opens any attachment so named in Playwright's trace viewer.
const TRACE_PAGE_NAME = 'walkthrough';

async function traceEvents(
  client: TestdinoClient,
  runId: string,
  projectRoot: string,
  pages: readonly TracePage[],
  deadline: () => number
): Promise<Omit<TestAttachmentsEvent, 'runId' | 'sequence'>[]> {
  if (pages.length === 0) return [];
  const attachments = await uploadFiles(
    client,
    runId,
    pages.map((page) => ({
      testId: page.testId,
      name: TRACE_PAGE_NAME,
      contentType: 'text/markdown',
      path: join(projectRoot, page.path),
    })),
    deadline
  );
  const timestamp = Date.now();
  return pages.map((page, index) => ({
    type: 'test:attachments',
    timestamp,
    testId: page.testId,
    retry: page.retry,
    attachments: [attachments[index]!],
  }));
}

// The server records the run's dashboard link once it has consumed run:begin,
// which over Kafka can lag the upload by a moment.
async function runLink(client: TestdinoClient, runId: string): Promise<string | undefined> {
  for (let attempt = 0; attempt < LINK_ATTEMPTS; attempt++) {
    const link = await client.resolveRunLink(runId).catch(() => undefined);
    if (link) return link;
    await new Promise((resolve) => setTimeout(resolve, LINK_RETRY_MS));
  }
  return undefined;
}

type Slices = Pick<RunBeginEvent, 'shard' | 'splitId' | 'split'>;

// Gives an event its run and its place in the run's single order.
type Stamp = <Event extends object>(event: Event) => Event & { runId: string; sequence: number };

// The run's shard and split, kept only when the server can merge them, with a
// note for each one it could not.
function runSlices(options: TestdinoOptions) {
  const notes: string[] = [];
  const ciRunId = options.ciRunId ?? process.env.TESTDINO_CI_RUN_ID;
  const splitId = options.splitId ?? process.env.TESTDINO_SPLIT_ID;
  let split = parseSlice(options.split ?? process.env.TESTDINO_SPLIT);
  if ((split && !splitId) || (!split && splitId)) {
    notes.push('split ignored: a split position and TESTDINO_SPLIT_ID are needed together');
    split = undefined;
  }
  let shard = parseSlice(process.env.TESTDINO_SHARD ?? shardFromArgv(process.argv));
  // A split groups its own shards by split id; elsewhere shards merge only under
  // a CI run id. Without either, one standalone run per shard beats losing it.
  if (shard && !ciRunId && !split) {
    notes.push('shards uploaded as separate runs: set TESTDINO_CI_RUN_ID to merge them');
    shard = undefined;
  }
  const slices: Slices = { ...(shard && { shard }), ...(split && splitId && { splitId, split }) };
  return { ciRunId, shard, slices, notes };
}

function normalizeTags(input: readonly string[] | string | undefined): string[] | undefined {
  if (input === undefined) return undefined;
  const tags = [...new Set((typeof input === 'string' ? input.split(',') : input).map((tag) => tag.trim()))];
  const kept = tags.filter((tag) => tag.length > 0);
  return kept.length > 0 ? kept : undefined;
}

// As `tdpw`: config tags win over TESTDINO_TAGS, and only a re-run appends TESTDINO_RERUN_TAGS.
function runTags(options: TestdinoOptions): string[] | undefined {
  const base = normalizeTags(options.tags) ?? normalizeTags(process.env.TESTDINO_TAGS);
  const rerunTags = process.env.TESTDINO_RERUN_OF ? normalizeTags(process.env.TESTDINO_RERUN_TAGS) : undefined;
  return rerunTags ? normalizeTags([...(base ?? []), ...rerunTags]) : base;
}

// run:begin, and the shard and split each later event repeats.
async function buildRunBegin(
  options: TestdinoOptions,
  run: {
    runId: string;
    startTime: number;
    projectId: string;
    projectRoot: string;
    frameworkVersion: string;
    targets: string[];
    skeleton: Skeleton;
    vcs: Parameters<typeof collectGit>[1];
  }
): Promise<{ runBegin: RunBeginEvent; slices: Slices; notes: string[] }> {
  const { ciRunId, shard, slices, notes } = runSlices(options);
  // Set by `testdino-e2e rerun`, so the dashboard links the re-run to its source.
  const rerunOf = process.env.TESTDINO_RERUN_OF;
  // Set by `testdino-e2e run --selection`, so the run page says what the selection found.
  const selection = selectionReport(process.env.TESTDINO_SELECTION);
  const tags = runTags(options);
  const git = await collectGit(run.projectRoot, run.vcs);
  const ci = collectCI();
  const actorIsAuthor = await resolveActorIsAuthor(run.projectRoot, ci, git.commit.email);
  const runBegin: RunBeginEvent = {
    type: 'run:begin',
    runId: run.runId,
    timestamp: run.startTime,
    sequence: 0,
    projectId: run.projectId,
    ...(ciRunId && { ciRunId }),
    ...slices,
    ...(tags && { tags }),
    ...(rerunOf && { rerunOf }),
    ...(selection && { selection }),
    metadata: {
      git,
      ci: actorIsAuthor === undefined || !('build' in ci) ? ci : { ...ci, build: { ...ci.build, actorIsAuthor } },
      system: collectSystem(),
      framework: { name: 'e2e', version: run.frameworkVersion },
      playwright: { projects: run.targets.map((name) => ({ name })), ...(shard && { shard }) },
      skeleton: run.skeleton,
    },
  };
  return { runBegin, slices, notes };
}

// Console output, code frames, and uploaded artifacts for tests about to be sent.
async function prepareTests(
  client: TestdinoClient,
  runId: string,
  dirs: { artifactsRoot: string; projectRoot: string },
  tests: readonly PlannedTest[],
  output: readonly CapturedOutput[],
  uploads: { enabled: boolean; deadline: () => number; stop?: AbortSignal }
): Promise<void> {
  await frameErrors(tests, dirs.projectRoot);
  attachOutput(tests, output);
  const attempts = tests.flatMap((test) => test.attempts.map((attempt) => ({ testId: test.testId, attempt })));
  await inPool(attempts, UPLOAD_CONCURRENCY, async ({ testId, attempt }) => {
    attempt.end.attachments =
      uploads.enabled && Date.now() < uploads.deadline()
        ? await uploadAttempt(client, runId, dirs.artifactsRoot, testId, attempt, uploads.deadline, uploads.stop)
        : unavailableArtifacts(attempt);
  });
}

function unavailableArtifacts(attempt: PlannedTest['attempts'][number]) {
  return attempt.artifacts.map((artifact) => ({
    name: attachmentName(attempt, artifact),
    contentType: artifact.mediaType,
    unavailable: true,
  }));
}

function testEvents(tests: readonly PlannedTest[], stamp: Stamp): WireEvent[] {
  return tests.flatMap((test) =>
    test.attempts.flatMap((attempt) => [stamp(attempt.begin), ...attempt.steps.map(stamp), stamp(attempt.end)])
  ) as WireEvent[];
}

type RunStarted = { runId: string; projectRoot: string; artifactsRoot: string; targets: readonly string[]; at: string };

interface Live {
  runId: string;
  /** Resolves once run:begin is delivered; undefined when it was not, and the final report sends the run whole. */
  begun: Promise<
    { client: TestdinoClient; auth: AuthResult; delivery: Delivery; slices: Slices; notes: string[] } | undefined
  >;
  plan(total: number): void;
  /** A test starting: its first attempt begins, so the dashboard lists it as running. */
  start(event: LiveStart): void;
  test(result: LiveResult): void;
  /** Every queued send has settled; a failed one stops the stream and leaves its tests to the final report. */
  settled(): Promise<void>;
  /** From now on the stream's uploads stop at `deadline` (epoch ms), the end-of-run budget. */
  finishBy(deadline: number): void;
  /** run:end went out, or never will: the run needs no more beats. */
  stopHeartbeat(): void;
  /** e2e forced the stop: uploads end now, and run-finished ends the run from the stream. */
  forceStop(): void;
  endIfForced(): void;
  /** The stream sent run:end; the final report must not send another. */
  readonly ended: boolean;
  sent: Set<string>;
  stamp: Stamp;
  abort: AbortController;
}

// One send at a time, in e2e's order. A failed send stops the queue: what is
// left goes out with the final report.
function serialQueue(onFailure: (error: unknown) => void) {
  let stopped = false;
  let queue: Promise<unknown> = Promise.resolve();
  return {
    enqueue(work: () => Promise<void>) {
      queue = queue
        .then(() => (stopped ? undefined : work()))
        .catch((error: unknown) => {
          stopped = true;
          onFailure(error);
        });
    },
    stop() {
      stopped = true;
    },
    drained: () => queue,
  };
}

// e2e names no worker: a test takes the lowest slot free when it starts, so the
// dashboard shows as many worker lines as tests running at once.
function workerSlots() {
  const busy = new Map<string, number>();
  return {
    take(key: string): number {
      const used = new Set(busy.values());
      let slot = 0;
      while (used.has(slot)) slot++;
      busy.set(key, slot);
      return slot;
    },
    release(key: string): number {
      const slot = busy.get(key) ?? 0;
      busy.delete(key);
      return slot;
    },
  };
}

// Live uploads have no deadline while the run goes on. When it ends they share
// its budget, and `stop` cuts off any upload already running at the deadline.
function liveUploads() {
  let deadline = Infinity;
  const stop = new AbortController();
  return {
    deadline: () => deadline,
    stop: stop.signal,
    finishBy(at: number) {
      deadline = at;
      setTimeout(() => stop.abort(), Math.max(0, at - Date.now())).unref();
    },
  };
}

// The streamed run:begin: e2e's plan names how many tests run, not which.
function selectionReport(raw: string | undefined): RunSelectionReport | undefined {
  if (!raw) return undefined;
  try {
    const report = JSON.parse(raw) as Partial<RunSelectionReport>;
    const valid =
      typeof report.id === 'string' &&
      (report.onMissing === 'skip' || report.onMissing === 'fail') &&
      Number.isInteger(report.requested) &&
      Number.isInteger(report.matched) &&
      Array.isArray(report.notFound);
    return valid ? (report as RunSelectionReport) : undefined;
  } catch {
    return undefined;
  }
}

function liveRunBegin(options: TestdinoOptions, started: RunStarted, plan: { projectId: string; total: number }) {
  let frameworkVersion = '';
  try {
    frameworkVersion = e2ePackage(started.projectRoot).version;
  } catch {
    // An e2e the project root cannot resolve still runs; its version is unknown.
  }
  return buildRunBegin(options, {
    runId: started.runId,
    startTime: Date.parse(started.at),
    projectId: plan.projectId,
    projectRoot: started.projectRoot,
    frameworkVersion,
    targets: [...started.targets],
    skeleton: { totalTests: plan.total, suites: [] },
    vcs: undefined,
  });
}

// Sent beside the queue, so a long upload in it cannot hold a beat back.
function beatOn(delivery: Delivery, stamp: Stamp): Heartbeat {
  return startHeartbeat(() => {
    delivery
      .send([stamp({ type: 'run:heartbeat', timestamp: Date.now() })] as WireEvent[])
      // A lost beat is covered by the next poll; a throw here would reach e2e, which drops the reporter.
      .catch(() => {});
  });
}

function openLiveSession(options: TestdinoOptions, client: TestdinoClient, serverUrl: string, runId: string) {
  return (async () => {
    const auth = await client.authenticate();
    const delivery = await openDelivery(client, auth, serverUrl, runId);
    debugLog(
      options,
      delivery ? `streaming over ${delivery.channel}` : 'no event channel the server offered could be reached'
    );
    return delivery && { auth, delivery };
  })().catch((error: unknown) => {
    debugLog(options, `could not start streaming: ${errorText(error)}`);
    return undefined;
  });
}

const EXIT_FLUSH = fileURLToPath(new URL('./exit-flush.js', import.meta.url));
// Bounds how long a forced Ctrl-C waits on the network before the process exits.
const EXIT_FLUSH_TIMEOUT_MS = 5_000;

// The run as it happens. Sends go through one queue, in e2e's order, and never
// throw back into e2e: onEvent must not block or throw.
class LiveStream implements Live {
  readonly runId: string;
  readonly sent = new Set<string>();
  readonly abort = new AbortController();
  readonly begun: Live['begun'];
  readonly stamp: Stamp;
  private readonly options: TestdinoOptions;
  private readonly started: RunStarted;
  private readonly output: () => readonly CapturedOutput[];
  private readonly client: TestdinoClient;
  private readonly opened: ReturnType<typeof openLiveSession>;
  private readonly queue = serialQueue((error) => {
    this.heartbeat?.stop();
    debugLog(this.options, `live stream stopped: ${errorText(error)}`);
  });
  private readonly uploads = liveUploads();
  private readonly slots = workerSlots();
  private resolveBegun!: (value: Awaited<Live['begun']>) => void;
  private heartbeat: Heartbeat | undefined;
  private forced = false;
  ended = false;
  private readonly token: string;
  private readonly serverUrl: string;
  private session: Streamed | undefined;
  // Batches handed to the channel and not yet acknowledged, and results not yet built.
  private readonly outbox = new Set<WireEvent[]>();
  private readonly unsent = new Map<LiveResult, number>();

  constructor(options: TestdinoOptions, token: string, started: RunStarted, output: () => readonly CapturedOutput[]) {
    this.options = options;
    this.started = started;
    this.output = output;
    this.runId = started.runId;
    const serverUrl = options.serverUrl ?? process.env.TESTDINO_SERVER_URL ?? DEFAULT_SERVER_URL;
    this.token = token;
    this.serverUrl = serverUrl;
    this.client = new TestdinoClient({ token, serverUrl, signal: this.abort.signal });
    let sequence = 0;
    this.stamp = (event) => ({ ...event, runId: started.runId, sequence: ++sequence });
    this.begun = new Promise((resolve) => (this.resolveBegun = resolve));
    this.opened = openLiveSession(options, this.client, serverUrl, started.runId);
    // A new run-started replaces this stream; its beats must not go on for the old run.
    this.abort.signal.addEventListener('abort', () => this.heartbeat?.stop(), { once: true });
  }

  plan(total: number): void {
    this.queue.enqueue(() => this.begin(total));
  }

  start(event: LiveStart): void {
    const slot = this.slots.take(
      wireTestId({ testId: event.testId, targetId: event.target, agent: event.agent, repeat: event.repeat })
    );
    this.queue.enqueue(async () => {
      const session = await this.begun;
      if (session) await this.deliver(session.delivery, [this.stamp(beginFromStart(event, slot))] as WireEvent[]);
    });
  }

  test(result: LiveResult): void {
    const slot = this.slots.release(
      wireTestId({ testId: result.test.id, targetId: result.target.name, agent: result.agent, repeat: result.repeat })
    );
    // A serial-group member maps from its group's record, which the final report holds.
    if (!result.selected || result.serialGroupId !== undefined) return;
    this.unsent.set(result, slot);
    this.queue.enqueue(() => this.send(result, slot));
  }

  forceStop(): void {
    if (this.forced) return;
    this.forced = true;
    this.uploads.finishBy(Date.now());
    // e2e exits as soon as its output is out, without waiting for reporters.
    process.once('exit', () => this.flushAtExit());
  }

  // e2e skips onRunFinished on a forced stop, so run:end goes out here, after the
  // interrupted tests already queued.
  endIfForced(): void {
    const session = this.session;
    if (!this.forced || this.ended || !session) return;
    this.ended = true;
    const startTime = Date.parse(this.started.at);
    const now = Date.now();
    const end = {
      type: 'run:end',
      timestamp: now,
      status: 'interrupted',
      duration: now - startTime,
      startTime,
      ...session.slices,
    };
    const batch = [this.stamp(end)] as WireEvent[];
    this.outbox.add(batch);
    debugLog(this.options, 'forced stop: ending the run as interrupted');
    this.queue.enqueue(async () => {
      await this.deliver(session.delivery, batch);
      this.heartbeat?.stop();
    });
  }

  // Sends what the queue did not get out before exit, in order, run:end last.
  private flushAtExit(): void {
    const session = this.session;
    if (!session || session.auth.overLimit) return;
    const run = { serialGroups: [], startedAt: this.started.at };
    const late = [...this.unsent].map(([result, slot]) => {
      const test = planTest(resultFromEvent(result, this.started.projectRoot), run, slot);
      for (const attempt of test.attempts) attempt.end.attachments = unavailableArtifacts(attempt);
      return testEvents([test], this.stamp);
    });
    const batches = [...this.outbox];
    const isEnd = (batch: WireEvent[]) => batch[0]?.type === 'run:end';
    const events = [...batches.filter((b) => !isEnd(b)), ...late, ...batches.filter(isEnd)].flat();
    if (events.length === 0) return;
    const { auth } = session;
    const payload = {
      channel: session.delivery.channel,
      url: auth.httpFallback ? new URL(auth.httpFallback, this.serverUrl).toString() : undefined,
      token: this.token,
      kafka: auth.kafka,
      events,
    };
    debugLog(this.options, `sending ${events.length} undelivered event(s) before exit`);
    const sent = spawnSync(process.execPath, [EXIT_FLUSH], {
      input: JSON.stringify(payload),
      timeout: EXIT_FLUSH_TIMEOUT_MS,
      stdio: ['pipe', 'ignore', 'ignore'],
    });
    debugLog(this.options, sent.status === 0 ? 'sent before exit' : 'could not send before exit');
  }

  finishBy(deadline: number): void {
    this.uploads.finishBy(deadline);
  }

  stopHeartbeat(): void {
    this.heartbeat?.stop();
  }

  async settled(): Promise<void> {
    await this.queue.drained();
    // A plan event that never came leaves run:begin unsent.
    this.resolveBegun(undefined);
    // The final report then opens its own channel; this one must not stay open.
    if (!(await this.begun)) await (await this.opened)?.delivery.close();
  }

  private async begin(total: number): Promise<void> {
    const session = await this.opened;
    if (!session) return this.resolveBegun(undefined);
    const { runBegin, slices, notes } = await liveRunBegin(this.options, this.started, {
      projectId: session.auth.projectId,
      total,
    });
    const streamed = { client: this.client, ...session, slices, notes };
    this.session = streamed;
    await this.deliver(session.delivery, [runBegin]).catch((error: unknown) => {
      this.session = undefined;
      this.outbox.clear();
      this.resolveBegun(undefined);
      throw error;
    });
    debugLog(this.options, `run:begin sent for ${total} tests`);
    this.resolveBegun(streamed);
    // Over the limit the run is recorded as begun and nothing more is sent.
    if (session.auth.overLimit) return this.queue.stop();
    this.heartbeat = beatOn(session.delivery, this.stamp);
  }

  private async send(result: LiveResult, slot: number): Promise<void> {
    const session = await this.begun;
    if (!session) return;
    const { started } = this;
    const run = { serialGroups: [], startedAt: started.at };
    const test = planTest(resultFromEvent(result, started.projectRoot), run, slot);
    const enabled = this.options.artifacts !== false;
    await prepareTests(this.client, started.runId, started, [test], this.output(), { enabled, ...this.uploads });
    const events = testEvents([test], this.stamp);
    this.unsent.delete(result);
    await this.deliver(session.delivery, events);
    this.sent.add(test.testId);
  }

  private async deliver(delivery: Delivery, events: WireEvent[]): Promise<void> {
    this.outbox.add(events);
    await delivery.send(events);
    this.outbox.delete(events);
    this.heartbeat?.sent();
  }
}

type FinishedRun = Parameters<NonNullable<Reporter['onRunFinished']>>[0];
type ReporterSummary = Exclude<Awaited<ReturnType<NonNullable<Reporter['onRunFinished']>>>, void>;

// What the final report sends through, and what it still has to send.
interface FinalSession {
  client: TestdinoClient;
  delivery: Delivery;
  slices: Slices;
  notes: string[];
  stamp: Stamp;
  tests: PlannedTest[];
  overLimit: boolean | undefined;
}

type Streamed = NonNullable<Awaited<Live['begun']>>;

// The stream already sent run:begin and the tests it could; the rest goes the same way.
function streamedSession(streamed: Streamed, live: Live, plan: RunPlan): FinalSession {
  const { client, delivery, slices, notes, auth } = streamed;
  const tests = plan.tests.filter((test) => !live.sent.has(test.testId));
  return { client, delivery, slices, notes, stamp: live.stamp, tests, overLimit: auth.overLimit };
}

// Nothing was streamed: the whole run goes out now. Undefined when no event
// channel the server offered could be reached.
async function openFinalSession(
  options: TestdinoOptions,
  connection: { token: string; serverUrl: string; signal: AbortSignal },
  { run, plan }: { run: FinishedRun; plan: RunPlan }
): Promise<FinalSession | undefined> {
  const client = new TestdinoClient(connection);
  const auth = await client.authenticate();
  const delivery = await openDelivery(client, auth, connection.serverUrl, plan.runId);
  if (!delivery) return undefined;
  try {
    const { runBegin, slices, notes } = await buildRunBegin(options, {
      runId: plan.runId,
      startTime: plan.startTime,
      projectId: auth.projectId,
      projectRoot: run.projectRoot,
      frameworkVersion: plan.frameworkVersion,
      targets: plan.targets,
      skeleton: plan.skeleton,
      vcs: run.report.run.vcs,
    });
    // run:begin goes first and alone: the server must know the run before it
    // mints artifact upload URLs for it.
    await delivery.send([runBegin]);
    let sequence = 0;
    const stamp: Stamp = (event) => ({ ...event, runId: plan.runId, sequence: ++sequence });
    return { client, delivery, slices, notes, stamp, tests: plan.tests, overLimit: auth.overLimit };
  } catch (error) {
    await delivery.close();
    throw error;
  }
}

// The tests left, their trace pages, the run errors and run:end, in one send.
async function sendRest(
  session: FinalSession,
  { run, plan }: { run: FinishedRun; plan: RunPlan },
  captured: {
    output: readonly CapturedOutput[];
    traces: Readonly<Record<string, string>>;
    uploads: { enabled: boolean; deadline: () => number };
  }
): Promise<void> {
  const { uploads } = captured;
  const { client, stamp, tests } = session;
  const dirs = { artifactsRoot: run.artifactsRoot, projectRoot: run.projectRoot };
  await prepareTests(client, plan.runId, dirs, tests, captured.output, uploads);
  const pages = tracePages(run.report, plan.tests, captured.traces);
  const late = uploads.enabled ? await traceEvents(client, plan.runId, run.projectRoot, pages, uploads.deadline) : [];
  await session.delivery.send([
    ...testEvents(tests, stamp),
    ...late.map(stamp),
    ...plan.runErrors.map(stamp),
    stamp({ ...plan.end, ...session.slices }),
  ] as WireEvent[]);
}

type RunEvent = Parameters<NonNullable<Reporter['onEvent']>>[0];

// What the reporter keeps between e2e's events for the run it is reporting.
interface ReporterState {
  output: CapturedOutput[];
  outputBytes: number;
  traces: Readonly<Record<string, string>>;
  live: Live | undefined;
  update?: UpdateCheck;
  // Set only under `testdino-e2e run`, which applies the decision to the exit code.
  controls?: Promise<QuarantineFetchOutcome>;
  controlsReport?: string[];
}

// `testdino-e2e run` names a file for the build decision; plain `npx e2e run` does not,
// and then Test Controls is neither applied nor reported, since nothing could act on it.
const DECISION_FILE_ENV = 'TESTDINO_DECISION_FILE';

function finishedTests(plan: RunPlan): FinishedTest[] {
  return plan.tests.flatMap((test) => {
    const last = test.attempts[test.attempts.length - 1];
    if (!last) return [];
    return [
      {
        id: test.testId,
        title: last.begin.title,
        outcome: last.end.outcome,
        errorMessage: last.end.errors[0]?.message ?? '',
      },
    ];
  });
}

// A serial group's failed hook fails the run with no failed test and no run error.
function failedSerialHooks(run: FinishedRun): number {
  return run.report.run.serialGroups.filter(
    (group) => group.status === 'failed' && !group.attempts.at(-1)?.members.some((member) => member.error)
  ).length;
}

async function applyTestControls(state: ReporterState, plan: RunPlan, run: FinishedRun): Promise<void> {
  const file = process.env[DECISION_FILE_ENV];
  if (!state.controls || !file) return;
  const decision = decideTestControls({
    fetch: await state.controls,
    tests: finishedTests(plan),
    runStatus: plan.end.status,
    exitCode: run.exitCode,
    globalErrorCount: plan.runErrors.length + failedSerialHooks(run),
  });
  plan.end.quarantine = decision.block;
  state.controlsReport = decision.report;
  // Written before anything is sent: an upload that fails must not undo the decision.
  writeFileSync(file, JSON.stringify({ build: decision.block.build }));
}

function captureOutput(state: ReporterState, event: Extract<RunEvent, { type: 'output' }>): void {
  if (!event.pair || state.outputBytes >= MAX_OUTPUT_BYTES) return;
  state.outputBytes += Buffer.byteLength(event.text);
  state.output.push({
    testId: event.pair.testId,
    targetId: event.target,
    agent: event.pair.agent,
    repeat: event.pair.repeat,
    stream: event.stream,
    text: event.text,
    at: Date.parse(event.at),
  });
}

// Sends what the stream did not, then run:end, and names the run's dashboard link.
async function finishRun(
  options: TestdinoOptions,
  state: ReporterState,
  { run, signal }: { run: FinishedRun; signal: AbortSignal }
): Promise<ReporterSummary> {
  const token = options.token ?? process.env.TESTDINO_TOKEN;
  if (!token) return [{ label: LABEL, text: 'skipped (TESTDINO_TOKEN is not set)' }];
  const serverUrl = options.serverUrl ?? process.env.TESTDINO_SERVER_URL ?? DEFAULT_SERVER_URL;
  const uploadDeadline = Date.now() + UPLOAD_BUDGET_MS;
  const uploads = { enabled: options.artifacts !== false, deadline: () => uploadDeadline };
  const current = state.live?.runId === run.report.run.id ? state.live : undefined;
  signal.addEventListener('abort', () => current?.abort.abort(), { once: true });
  // Uploads the stream still has queued share the budget, so run:end goes out inside e2e's minute.
  current?.finishBy(uploadDeadline);

  let delivery: Delivery | undefined;
  try {
    await current?.settled();
    const streamed = await current?.begun;
    delivery = streamed?.delivery;
    if (current?.ended) return [{ label: LABEL, text: 'stopped; the test run was ended as interrupted' }];
    const plan = planRun(run.report);
    await applyTestControls(state, plan, run);
    const session =
      streamed && current
        ? streamedSession(streamed, current, plan)
        : await openFinalSession(options, { token, serverUrl, signal }, { run, plan });
    if (!session)
      return [{ label: LABEL, text: 'not uploaded (no event channel the server offered could be reached)' }];
    delivery = session.delivery;
    if (session.overLimit) return [{ label: LABEL, text: 'not recorded (the project is over its execution limit)' }];
    await sendRest(session, { run, plan }, { output: state.output, traces: state.traces, uploads });
    debugLog(options, `run:end sent for ${plan.skeleton.totalTests} tests`);
    // run:end is out; a beat after it is for a run the server has closed.
    current?.stopHeartbeat();
    const link = await runLink(session.client, plan.runId);
    const summary = link ?? `uploaded ${plan.skeleton.totalTests} tests`;
    return [{ label: LABEL, text: session.notes.length ? `${summary} (${session.notes.join('; ')})` : summary }];
  } catch (error) {
    return [{ label: LABEL, text: `upload failed: ${error instanceof Error ? error.message : String(error)}` }];
  } finally {
    // Also on every early return and failure, and when planning the report throws.
    current?.stopHeartbeat();
    await delivery?.close();
  }
}

export function testdino(options: TestdinoOptions = {}): Reporter {
  const state: ReporterState = { output: [], outputBytes: 0, traces: {}, live: undefined };
  return {
    name: 'testdino',

    onEvent(event) {
      try {
        if (event.type === 'run-started') {
          // Not at construction: e2e builds a reporter in every worker, and that must have no side effects.
          if (!state.update && !process.env.NO_UPDATE_NOTIFIER) state.update = startUpdateCheck(REPORTER_VERSION);
          const token = options.token ?? process.env.TESTDINO_TOKEN;
          const serverUrl = options.serverUrl ?? process.env.TESTDINO_SERVER_URL ?? DEFAULT_SERVER_URL;
          state.controls = token && process.env[DECISION_FILE_ENV] ? fetchQuarantineList(serverUrl, token) : undefined;
          state.controlsReport = undefined;
          state.live?.abort.abort();
          Object.assign(state, { output: [], outputBytes: 0, traces: {}, live: undefined });
          if (token) state.live = new LiveStream(options, token, event, () => state.output);
          return;
        }
        // `total` also counts the tests filters left out (file args, --grep, tags, --shard, a re-run);
        // `files[].tests` counts only those that run or are skipped, the ones the run reports.
        if (event.type === 'plan') return state.live?.plan(event.files.reduce((sum, file) => sum + file.tests, 0));
        // Older e2e versions write no trace pages and name none here.
        if (event.type === 'run-finished') {
          state.traces = (event as { traces?: Readonly<Record<string, string>> }).traces ?? {};
          return state.live?.endIfForced();
        }
        // Under `npx e2e run` one Ctrl-C reaches e2e twice, and the second forces the stop.
        if (event.type === 'run-interrupted') return event.mode === 'forced' ? state.live?.forceStop() : undefined;
        if (event.type === 'test-started') return state.live?.start(event);
        // The live result and the report's share every field mapping reads; only
        // the identity's nesting and the declaration's path differ (resultFromEvent).
        if (event.type === 'test-finished') return state.live?.test(event.result as unknown as LiveResult);
        if (event.type === 'output') captureOutput(state, event);
      } catch {
        // A reporter that throws is dropped for the rest of the run; the final report still sends it.
      }
    },

    async onRunFinished(run, signal) {
      const rows = [
        ...(await finishRun(options, state, { run, signal })),
        ...(state.controlsReport ?? []).map((text) => ({ label: LABEL, text })),
      ];
      const latest = await state.update?.result();
      state.update = undefined;
      if (!latest) return rows;
      const text = `@testdino/e2e ${latest} is available (installed ${REPORTER_VERSION}): npm install --save-dev @testdino/e2e@latest`;
      return [...rows, { label: LABEL, text }];
    },
  };
}
