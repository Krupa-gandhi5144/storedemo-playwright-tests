// Collects the git, CI, and system context a TestDino run carries.
import { execFile } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { cpus, hostname, platform, release, totalmem, type as osType } from 'node:os';
import { promisify } from 'node:util';

const run = promisify(execFile);

const pkg = createRequire(import.meta.url)('../package.json') as { version: string };
export const REPORTER_VERSION = pkg.version;

async function git(cwd: string, args: string[]): Promise<string> {
  try {
    const { stdout } = await run('git', args, { cwd, timeout: 5000 });
    return stdout.trim();
  } catch {
    // Not a git checkout, or git is missing: the field stays empty.
    return '';
  }
}

function repositoryName(remoteUrl: string): string {
  const match = /[/:]([^/:]+\/[^/]+?)(?:\.git)?$/.exec(remoteUrl);
  return match?.[1] ?? '';
}

// A remote URL can embed a token (https://user:token@host/...); never report it.
function withoutCredentials(remoteUrl: string): string {
  return remoteUrl.replace(/^(https?:\/\/)[^/@]+@/, '$1');
}

interface CIPullRequest {
  number: number;
  title?: string;
  url?: string;
  status?: string;
  branch?: string;
  targetBranch?: string;
}

// git@host:org/repo(.git) and ssh://host/org/repo become https://host/org/repo.
function remoteToHttps(url: string): string {
  const trimmed = url.trim();
  const shorthand = /^git@([^:]+):(.+?)(?:\.git)?$/i.exec(trimmed);
  if (shorthand) return `https://${shorthand[1]}/${shorthand[2]}`;
  const ssh = /^(?:ssh|git):\/\/(?:[^@/]+@)?([^/]+)\/(.+?)(?:\.git)?$/i.exec(trimmed);
  if (ssh) return `https://${ssh[1]}/${ssh[2]}`;
  return withoutCredentials(trimmed.replace(/\.git$/, ''));
}

// Only exact hosts or their subdomains: `github.evil.com` must never yield a PR link.
function pullRequestUrl(repoUrl: string, id: string): string | undefined {
  const repo = remoteToHttps(repoUrl);
  let host: string;
  try {
    host = new URL(repo).hostname.toLowerCase();
  } catch {
    return undefined;
  }
  const is = (domain: string) => host === domain || host.endsWith(`.${domain}`);
  const enterprise = (process.env.TESTDINO_GHE_HOSTS ?? '').split(',').map((h) => h.trim().toLowerCase());
  if (is('github.com') || enterprise.includes(host)) return `${repo}/pull/${id}`;
  if (is('bitbucket.org')) return `${repo}/pull-requests/${id}`;
  if (is('gitlab.com')) return `${repo}/-/merge_requests/${id}`;
  return undefined;
}

const refName = (ref: string) => ref.replace(/^refs\/heads\//, '');

// The branch and pull request each CI names, as @testdino/playwright reads them
// (src/metadata/git.ts). On a detached checkout git alone knows neither.
export function ciGitContext(provider: string | undefined, env = process.env): { branch?: string; pr?: CIPullRequest } {
  let branch: string | undefined;
  let pr: Omit<CIPullRequest, 'number'> & { id?: string } = {};
  switch (provider) {
    case 'gitlab-ci':
      branch = env.CI_COMMIT_BRANCH || env.CI_MERGE_REQUEST_SOURCE_BRANCH_NAME || env.CI_COMMIT_REF_NAME;
      if (env.CI_MERGE_REQUEST_IID) {
        pr = {
          id: env.CI_MERGE_REQUEST_IID,
          title: env.CI_MERGE_REQUEST_TITLE,
          url: env.CI_PROJECT_URL && `${env.CI_PROJECT_URL}/-/merge_requests/${env.CI_MERGE_REQUEST_IID}`,
          branch: env.CI_MERGE_REQUEST_SOURCE_BRANCH_NAME,
          targetBranch: env.CI_MERGE_REQUEST_TARGET_BRANCH_NAME,
        };
      }
      break;
    case 'azure-devops':
      branch =
        env.BUILD_REASON === 'PullRequest' && env.SYSTEM_PULLREQUEST_SOURCEBRANCH
          ? refName(env.SYSTEM_PULLREQUEST_SOURCEBRANCH)
          : env.BUILD_SOURCEBRANCH
            ? refName(env.BUILD_SOURCEBRANCH)
            : env.BUILD_SOURCEBRANCHNAME;
      if (env.SYSTEM_PULLREQUEST_PULLREQUESTID) {
        const repo =
          env.SYSTEM_PULLREQUEST_SOURCEREPOSITORYURI && withoutCredentials(env.SYSTEM_PULLREQUEST_SOURCEREPOSITORYURI);
        pr = {
          id: env.SYSTEM_PULLREQUEST_PULLREQUESTID,
          title: env.SYSTEM_PULLREQUEST_PULLREQUESTTITLE,
          url: repo && `${repo}/pullrequest/${env.SYSTEM_PULLREQUEST_PULLREQUESTID}`,
        };
      }
      break;
    case 'jenkins':
      branch = (env.BRANCH_NAME || env.GIT_BRANCH)?.replace('origin/', '');
      if (env.ghprbPullId) {
        pr = {
          id: env.ghprbPullId,
          title: env.ghprbPullTitle,
          url: env.ghprbPullLink && withoutCredentials(env.ghprbPullLink),
        };
      }
      break;
    case 'circleci':
      branch = env.CIRCLE_BRANCH;
      if (env.CIRCLE_PR_NUMBER || env.CIRCLE_PULL_REQUEST) {
        pr = {
          id: env.CIRCLE_PR_NUMBER || /\/pull\/(\d+)$/.exec(env.CIRCLE_PULL_REQUEST ?? '')?.[1],
          url: env.CIRCLE_PULL_REQUEST && withoutCredentials(env.CIRCLE_PULL_REQUEST),
          ...(!env.CIRCLE_TAG && env.CIRCLE_PULL_REQUEST && { status: 'open' }),
        };
      }
      break;
    case 'aws-codebuild': {
      const source = env.CODEBUILD_SOURCE_VERSION;
      branch = env.CODEBUILD_WEBHOOK_HEAD_REF
        ? refName(env.CODEBUILD_WEBHOOK_HEAD_REF)
        : source && !source.startsWith('pr/') && !/^[0-9a-f]{40}$/.test(source)
          ? refName(source)
          : undefined;
      const id = /^pr\/(\d+)$/.exec(env.CODEBUILD_WEBHOOK_TRIGGER ?? '')?.[1];
      if (id) {
        pr = {
          id,
          status: 'open',
          url: env.CODEBUILD_SOURCE_REPO_URL && pullRequestUrl(env.CODEBUILD_SOURCE_REPO_URL, id),
        };
      }
      break;
    }
    case 'bitbucket-pipelines':
      branch = env.BITBUCKET_BRANCH;
      if (env.BITBUCKET_PR_ID) {
        const repo =
          env.BITBUCKET_WORKSPACE && env.BITBUCKET_REPO_SLUG
            ? `https://bitbucket.org/${env.BITBUCKET_WORKSPACE}/${env.BITBUCKET_REPO_SLUG}`
            : undefined;
        pr = {
          id: env.BITBUCKET_PR_ID,
          status: 'open',
          url: repo && `${repo}/pull-requests/${env.BITBUCKET_PR_ID}`,
          targetBranch: env.BITBUCKET_PR_DESTINATION_BRANCH,
        };
      }
      break;
    case 'buildkite':
      branch = env.BUILDKITE_BRANCH;
      // BUILDKITE_PULL_REQUEST is the number, or the literal "false".
      if (env.BUILDKITE_PULL_REQUEST && env.BUILDKITE_PULL_REQUEST !== 'false') {
        pr = {
          id: env.BUILDKITE_PULL_REQUEST,
          status: 'open',
          branch: env.BUILDKITE_BRANCH,
          targetBranch: env.BUILDKITE_PULL_REQUEST_BASE_BRANCH,
          url: env.BUILDKITE_REPO && pullRequestUrl(env.BUILDKITE_REPO, env.BUILDKITE_PULL_REQUEST),
        };
      }
      break;
    case 'harness':
      branch = env.DRONE_SOURCE_BRANCH || env.DRONE_COMMIT_BRANCH || env.DRONE_BRANCH;
      if (env.DRONE_PULL_REQUEST) {
        pr = {
          id: env.DRONE_PULL_REQUEST,
          status: 'open',
          branch: env.DRONE_SOURCE_BRANCH,
          targetBranch: env.DRONE_TARGET_BRANCH,
          url: env.DRONE_REPO_LINK && pullRequestUrl(env.DRONE_REPO_LINK, env.DRONE_PULL_REQUEST),
        };
      }
      break;
  }
  branch ||= env.CI_BRANCH || env.BRANCH_NAME || env.GIT_BRANCH || undefined;

  const { id, ...rest } = pr;
  const number = Number(id);
  const fields = Object.fromEntries(Object.entries(rest).filter(([, value]) => value)) as Omit<CIPullRequest, 'number'>;
  return {
    ...(branch && { branch }),
    ...(id && Number.isInteger(number) && number > 0 && { pr: { number, ...fields } }),
  };
}

export async function collectGit(
  projectRoot: string,
  vcs: { commit: string; branch?: string; dirty?: boolean } | undefined
) {
  const { env } = process;
  const [message, author, email, timestamp, remoteUrl, headBranch] = await Promise.all([
    git(projectRoot, ['log', '-1', '--format=%B']),
    git(projectRoot, ['log', '-1', '--format=%an']),
    git(projectRoot, ['log', '-1', '--format=%ae']),
    git(projectRoot, ['log', '-1', '--format=%aI']),
    git(projectRoot, ['config', '--get', 'remote.origin.url']),
    git(projectRoot, ['rev-parse', '--abbrev-ref', 'HEAD']),
  ]);
  const url = withoutCredentials(remoteUrl);
  const onPullRequest = env.GITHUB_EVENT_NAME?.startsWith('pull_request') === true;
  const pullRequest = onPullRequest ? readGitHubEvent(env)?.pull_request : undefined;
  // A pull request checkout is GitHub's merge commit; the commit that ran is the PR's head.
  const headSha = typeof pullRequest?.head?.sha === 'string' ? pullRequest.head.sha : undefined;
  const [headMessage, headAuthor, headEmail, headTimestamp] = headSha
    ? await Promise.all(
        ['%B', '%an', '%ae', '%aI'].map((format) => git(projectRoot, ['log', '-1', `--format=${format}`, headSha]))
      )
    : [];

  // On a pull_request event GITHUB_REF is refs/pull/<number>/merge.
  const prNumber = onPullRequest ? Number(/refs\/pull\/(\d+)\//.exec(env.GITHUB_REF ?? '')?.[1]) : NaN;
  const githubPr = Number.isInteger(prNumber)
    ? {
        number: prNumber,
        ...(typeof pullRequest?.title === 'string' && { title: pullRequest.title }),
        ...(typeof pullRequest?.state === 'string' && { status: pullRequest.state }),
        url:
          env.GITHUB_SERVER_URL && env.GITHUB_REPOSITORY
            ? `${env.GITHUB_SERVER_URL}/${env.GITHUB_REPOSITORY}/pull/${prNumber}`
            : '',
        branch: env.GITHUB_HEAD_REF ?? '',
        targetBranch: env.GITHUB_BASE_REF ?? '',
        author: env.GITHUB_ACTOR ?? '',
        merged: false,
      }
    : undefined;
  const provider = detectCIProvider();
  const ci = ciGitContext(provider);
  const pr = githubPr ?? (ci.pr && { ...ci.pr, merged: false });
  const gitBranch = vcs?.branch || (headBranch === 'HEAD' ? '' : headBranch);

  return {
    // A CI checkout is often a detached HEAD, so on CI its own branch wins; locally git does.
    branch:
      env.GITHUB_HEAD_REF || env.GITHUB_REF_NAME || (provider ? ci.branch || gitBranch : gitBranch || ci.branch) || '',
    ...(pr && { pr }),
    commit: {
      hash: headSha ?? vcs?.commit ?? (await git(projectRoot, ['rev-parse', 'HEAD'])),
      message: headMessage || message,
      author: headAuthor || author,
      authorId: '',
      email: headEmail || email,
      timestamp: headTimestamp || timestamp,
      isDirty: vcs?.dirty ?? false,
    },
    repository: { name: env.GITHUB_REPOSITORY || repositoryName(url), url },
  };
}

function detectCIProvider(): string | undefined {
  const { env } = process;
  if (env.GITHUB_ACTIONS === 'true') return 'github-actions';
  if (env.GITLAB_CI === 'true') return 'gitlab-ci';
  if (env.JENKINS_URL) return 'jenkins';
  if (env.TF_BUILD === 'True' || env.AZURE_HTTP_USER_AGENT) return 'azure-devops';
  if (env.CIRCLECI === 'true') return 'circleci';
  if (env.CODEBUILD_BUILD_ID) return 'aws-codebuild';
  if (env.BITBUCKET_BUILD_NUMBER) return 'bitbucket-pipelines';
  if (env.BUILDKITE === 'true') return 'buildkite';
  if (env.HARNESS_BUILD_ID || env.HARNESS_PIPELINE_ID) return 'harness';
  if (env.TEAMCITY_VERSION) return 'teamcity';
  return undefined;
}

// GitHub's `{id}+{login}@users.noreply.github.com` (or the older `{login}@...`) belongs to that login.
const NOREPLY_EMAIL = /^(?:\d+\+)?([^@]+)@users\.noreply\.github\.com$/i;

function readGitHubEvent(env: NodeJS.ProcessEnv) {
  try {
    return JSON.parse(readFileSync(env.GITHUB_EVENT_PATH ?? '', 'utf8')) as {
      head_commit?: { author?: { username?: unknown } };
      pull_request?: { title?: unknown; state?: unknown; head?: { sha?: unknown } };
    };
  } catch {
    return undefined;
  }
}

/**
 * Whether the person who started the run wrote the commit, from evidence only (an
 * account login or matching emails), as @testdino/playwright decides it; undefined
 * when the CI cannot tell.
 */
export async function resolveActorIsAuthor(
  projectRoot: string,
  ci: { provider: string; build?: { actor?: string } },
  commitEmail: string,
  env = process.env
): Promise<boolean | undefined> {
  const actor = ci.build?.actor;
  if (!actor) return undefined;
  const sameEmail = (a?: string, b?: string) => (a && b ? a.toLowerCase() === b.toLowerCase() : undefined);

  switch (ci.provider) {
    case 'github-actions': {
      const event = readGitHubEvent(env);
      const login = event?.head_commit?.author?.username;
      if (typeof login === 'string' && login) return login.toLowerCase() === actor.toLowerCase();
      // On a pull request HEAD is GitHub's merge commit; the pull request's own head commit is the evidence.
      const head = event?.pull_request?.head?.sha;
      const email =
        typeof head === 'string' && head ? await git(projectRoot, ['log', '-1', '--format=%ae', head]) : commitEmail;
      return NOREPLY_EMAIL.exec(email)?.[1]?.toLowerCase() === actor.toLowerCase() || undefined;
    }
    case 'gitlab-ci':
      return sameEmail(env.GITLAB_USER_EMAIL, commitEmail);
    case 'azure-devops':
      return sameEmail(env.BUILD_REQUESTEDFOREMAIL, commitEmail);
    case 'buildkite':
      return sameEmail(env.BUILDKITE_BUILD_CREATOR_EMAIL, env.BUILDKITE_BUILD_AUTHOR_EMAIL || commitEmail);
    default:
      return undefined;
  }
}

export function collectCI() {
  const { env } = process;
  const provider = detectCIProvider();
  const environment = {
    name: osType(),
    type: process.platform,
    os: `${platform()} ${release()}`,
    node: process.version,
  };

  if (!provider) return { provider: 'local', environment };
  return { provider, ...providerMetadata(provider, env), environment };
}

interface ProviderMetadata {
  pipeline: { id?: string; name?: string; url?: string; attempt?: number };
  build: { number?: string; trigger?: string; actor?: string };
}

// Mirrors the Playwright reporter's CIMetadataCollector, so a run carries the same
// pipeline and build fields whichever reporter sent it.
function providerMetadata(provider: string, env: NodeJS.ProcessEnv): ProviderMetadata {
  switch (provider) {
    case 'github-actions': {
      const { GITHUB_SERVER_URL, GITHUB_REPOSITORY, GITHUB_RUN_ID } = env;
      return {
        pipeline: {
          id: GITHUB_RUN_ID,
          name: env.GITHUB_WORKFLOW,
          url:
            GITHUB_SERVER_URL && GITHUB_REPOSITORY && GITHUB_RUN_ID
              ? `${GITHUB_SERVER_URL}/${GITHUB_REPOSITORY}/actions/runs/${GITHUB_RUN_ID}`
              : undefined,
          attempt: parseRunAttempt(env.GITHUB_RUN_ATTEMPT),
        },
        // GITHUB_ACTOR stays the first attempt's initiator on a re-run.
        build: {
          number: env.GITHUB_RUN_NUMBER,
          trigger: env.GITHUB_EVENT_NAME,
          actor: env.GITHUB_TRIGGERING_ACTOR || env.GITHUB_ACTOR,
        },
      };
    }
    case 'gitlab-ci':
      return {
        pipeline: {
          id: env.CI_PIPELINE_ID,
          name: env.CI_PIPELINE_SOURCE
            ? `${env.CI_PIPELINE_SOURCE} pipeline`
            : env.CI_COMMIT_TITLE || env.CI_PIPELINE_NAME || undefined,
          url: env.CI_PIPELINE_URL,
        },
        build: {
          number: env.CI_JOB_ID || env.CI_PIPELINE_IID,
          trigger: env.CI_PIPELINE_SOURCE,
          actor: env.GITLAB_USER_NAME || env.GITLAB_USER_LOGIN,
        },
      };
    case 'circleci':
      return {
        pipeline: {
          id: env.CIRCLE_PIPELINE_ID || env.CIRCLE_BUILD_NUM,
          name: env.CIRCLE_JOB,
          url: env.CIRCLE_BUILD_URL,
        },
        build: {
          number: env.CIRCLE_BUILD_NUM,
          trigger: env.CIRCLE_TAG ? 'tag' : env.CIRCLE_PR_NUMBER || env.CIRCLE_PULL_REQUEST ? 'pr' : 'push',
        },
      };
    case 'jenkins':
      return {
        pipeline: { id: env.BUILD_ID, name: env.JOB_NAME, url: env.BUILD_URL },
        build: { number: env.BUILD_NUMBER, trigger: jenkinsTrigger(env) },
      };
    case 'azure-devops': {
      const { SYSTEM_TEAMFOUNDATIONSERVERURI, SYSTEM_TEAMPROJECT, BUILD_BUILDID } = env;
      return {
        pipeline: {
          id: BUILD_BUILDID,
          name: env.BUILD_DEFINITIONNAME,
          url:
            SYSTEM_TEAMFOUNDATIONSERVERURI && SYSTEM_TEAMPROJECT && BUILD_BUILDID
              ? `${SYSTEM_TEAMFOUNDATIONSERVERURI.replace(/\/$/, '')}/${encodeURIComponent(SYSTEM_TEAMPROJECT)}/_build/results?buildId=${BUILD_BUILDID}`
              : undefined,
        },
        build: { number: env.BUILD_BUILDNUMBER, trigger: env.BUILD_REASON, actor: env.BUILD_REQUESTEDFOR },
      };
    }
    case 'aws-codebuild':
      return {
        // The build id is `project-name:build-uuid`.
        pipeline: {
          id: env.CODEBUILD_BUILD_ID,
          name: (env.CODEBUILD_BUILD_ID ?? '').split(':')[0] || undefined,
          url: env.CODEBUILD_BUILD_URL,
        },
        build: {
          number: env.CODEBUILD_BUILD_NUMBER,
          trigger:
            env.CODEBUILD_WEBHOOK_EVENT ||
            (env.CODEBUILD_INITIATOR
              ? env.CODEBUILD_INITIATOR.startsWith('codepipeline/')
                ? 'codepipeline'
                : 'manual'
              : undefined),
        },
      };
    case 'bitbucket-pipelines': {
      const { BITBUCKET_WORKSPACE, BITBUCKET_REPO_SLUG, BITBUCKET_BUILD_NUMBER } = env;
      return {
        pipeline: {
          id: env.BITBUCKET_PIPELINE_UUID,
          name: 'Bitbucket Pipeline',
          url:
            BITBUCKET_WORKSPACE && BITBUCKET_REPO_SLUG && BITBUCKET_BUILD_NUMBER
              ? `https://bitbucket.org/${BITBUCKET_WORKSPACE}/${BITBUCKET_REPO_SLUG}/pipelines/results/${BITBUCKET_BUILD_NUMBER}`
              : undefined,
        },
        build: {
          number: BITBUCKET_BUILD_NUMBER,
          trigger: env.BITBUCKET_PR_ID ? 'pull_request' : env.BITBUCKET_TAG ? 'tag' : 'push',
        },
      };
    }
    case 'buildkite':
      return {
        pipeline: {
          id: env.BUILDKITE_PIPELINE_ID || env.BUILDKITE_PIPELINE_SLUG,
          name: env.BUILDKITE_PIPELINE_NAME || env.BUILDKITE_PIPELINE_SLUG,
          url: env.BUILDKITE_BUILD_URL,
        },
        build: {
          number: env.BUILDKITE_BUILD_NUMBER,
          trigger: buildkiteTrigger(env),
          actor: env.BUILDKITE_BUILD_CREATOR,
        },
      };
    case 'harness':
      // Harness mirrors Drone's DRONE_* vars; it has no pipeline-name or results-URL var.
      return {
        pipeline: { id: env.HARNESS_PIPELINE_ID },
        build: {
          number: env.HARNESS_BUILD_ID || env.DRONE_BUILD_NUMBER,
          trigger: env.DRONE_BUILD_EVENT === 'cron' ? 'scheduled' : env.DRONE_BUILD_EVENT || undefined,
        },
      };
    default:
      return { pipeline: {}, build: { number: env.CI_BUILD_NUMBER || env.BUILD_NUMBER } };
  }
}

// Jenkins sets one boolean per cause; BUILD_CAUSE is the legacy single value.
function jenkinsTrigger(env: NodeJS.ProcessEnv): string | undefined {
  if (env.BUILD_CAUSE_MANUALTRIGGER === 'true') return 'manual';
  if (env.BUILD_CAUSE_SCMTRIGGER === 'true') return 'push';
  if (env.BUILD_CAUSE_TIMERTRIGGER === 'true') return 'scheduled';
  if (env.BUILD_CAUSE_UPSTREAMTRIGGER === 'true') return 'upstream';
  if (env.BUILD_CAUSE_REMOTECAUSE === 'true') return 'remote';
  return env.BUILD_CAUSE;
}

// BUILDKITE_PULL_REQUEST is the literal 'false' off a PR; a git push arrives as source 'webhook'.
function buildkiteTrigger(env: NodeJS.ProcessEnv): string {
  if (env.BUILDKITE_TAG) return 'tag';
  if (env.BUILDKITE_PULL_REQUEST && env.BUILDKITE_PULL_REQUEST !== 'false') return 'pull_request';
  switch (env.BUILDKITE_SOURCE) {
    case undefined:
    case '':
    case 'webhook':
      return 'push';
    case 'ui':
      return 'manual';
    case 'schedule':
      return 'scheduled';
    default:
      return env.BUILDKITE_SOURCE;
  }
}

// The server reads only a positive integer, so anything else is omitted.
function parseRunAttempt(value: string | undefined): number | undefined {
  return value !== undefined && /^[1-9]\d*$/.test(value) ? Number(value) : undefined;
}

export function collectSystem() {
  const cpuList = cpus();
  return {
    os: `${platform()} ${release()}`,
    cpu: cpuList.length > 0 ? `${cpuList[0]?.model.trim()} (${cpuList.length} cores)` : 'unknown',
    memory: `${(totalmem() / 1024 ** 3).toFixed(1)} GB`,
    nodeVersion: process.version,
    platform: platform(),
    hostname: hostname(),
    reporterVersion: REPORTER_VERSION,
    // Only `testdino-e2e run` names a decision file; the dashboard offers a narrowed CI retry for its runs alone.
    launcher: process.env.TESTDINO_DECISION_FILE ? 'testdino-e2e' : 'e2e',
  };
}
