// @ts-check
// `testdino-e2e rerun`: runs again the tests that failed in a TestDino run.
//
// Plain JavaScript, not TypeScript like the rest of the package: an installed
// bin lives in node_modules, where Node refuses to strip types. e2e's own test
// filters cannot do this either, because e2e runs them only when files changed
// since the merge base, and a re-run is usually of the same commit. So the
// failed tests become exact --grep patterns on an ordinary `e2e run`.
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { lastFailedReport, listPairs, pairLine } from './pairs.js';
import { DEFAULT_SERVER_URL } from './server.js';

const SCOPES = ['failed', 'flaky', 'failed-and-flaky'];
// The server writes a run's results a moment after it finishes, longer on a cold
// pipeline; waiting beats concluding that nothing failed.
const NOT_READY_BUDGET_MS = 90_000;
const NOT_READY_POLL_MS = 2_000;
const REQUEST_TIMEOUT_MS = 15_000;
const SEPARATOR = ' › ';
// Windows refuses a command line longer than 32,767 characters.
export const WINDOWS_MAX_COMMAND_CHARS = 32_767;
// Room for the e2e bin's path, which this module does not know (Windows' MAX_PATH).
const BIN_PATH_ALLOWANCE = 260;

/**
 * One argument as libuv quotes it for Windows: unchanged without a space, tab
 * or quote; otherwise in quotes, each quote escaped, and the backslashes before
 * a quote or the closing quote doubled. An empty argument is `""`.
 * @param {string} arg
 */
function windowsArgLength(arg) {
  if (arg.length > 0 && !/[\s"]/.test(arg)) return arg.length;
  const quotes = arg.match(/"/g)?.length ?? 0;
  const doubled = [...arg.matchAll(/(\\+)(?="|$)/g)].reduce((sum, run) => sum + (run[1] ?? '').length, 0);
  return arg.length + 2 + quotes + doubled;
}

/**
 * The command line Windows builds for node, the e2e bin and the arguments.
 * @param {readonly string[]} args
 * @param {string} [execPath]
 */
export function windowsCommandLength(args, execPath = process.execPath) {
  return [execPath, ...args].reduce((length, arg) => length + 1 + windowsArgLength(arg), BIN_PATH_ALLOWANCE);
}

const USAGE =
  'Usage: testdino-e2e rerun --from-run <runId> [--scope failed|flaky|failed-and-flaky] [--test-ids a,b] [--exclude-ids a,b] [--rerun-tags a,b] [-- <e2e run options>]';

export class RerunError extends Error {}

/**
 * The exit code under Test Controls: only a plain test failure (1) or a pass (0)
 * changes; configuration, infrastructure, internal and interrupt exits never do.
 * @param {number} code e2e's exit code
 * @param {'passed' | 'failed' | undefined} build the reporter's decision
 */
export function exitCodeFor(code, build) {
  if (code === 1 && build === 'passed') return 0;
  if (code === 0 && build === 'failed') return 1;
  return code;
}

/** @param {string} file */
function readBuild(file) {
  try {
    const { build } = JSON.parse(readFileSync(file, 'utf8'));
    return build === 'passed' || build === 'failed' ? build : undefined;
  } catch {
    // No decision (no token, Test Controls unreachable, a forced stop): e2e's code stands.
    return undefined;
  }
}

/**
 * Runs e2e with a file for the reporter's Test Controls decision and applies it.
 * @param {{ log: (line: string) => void; spawnE2e: (args: string[], env: Record<string, string | undefined>) => Promise<number> }} io
 * @param {string[]} args
 * @param {Record<string, string | undefined>} env
 */
export async function withTestControls(io, args, env) {
  const dir = mkdtempSync(join(tmpdir(), 'testdino-e2e-run-'));
  try {
    const decision = join(dir, 'decision.json');
    const code = await io.spawnE2e(args, { ...env, TESTDINO_DECISION_FILE: decision });
    const exitCode = exitCodeFor(code, readBuild(decision));
    if (exitCode !== code) {
      io.log(
        exitCode === 0
          ? 'TestDino: every failure is quarantined, so the build passes (exit 0).'
          : 'TestDino: a critical test passed only on retry, so the build fails (exit 1).'
      );
    }
    return exitCode;
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

const PICKED_OUTPUT = join('.e2e', 'testdino-picked');
const VALUE_FLAGS = ['--from-run', '--scope', '--test-ids', '--exclude-ids', '--rerun-tags'];

/** @param {string | undefined} value a comma-separated list, as the dashboard and a workflow input pass it */
const idList = (value) => (value ?? '').split(',').filter(Boolean);

/**
 * @param {readonly string[]} argv the arguments after the program name
 * @returns {{ fromRun: string; scope: string; testIds: string[]; excludeIds: string[]; rerunTags: string | undefined; passthrough: string[] }}
 */
export function parseRerunArgs(argv) {
  const [command, ...rest] = argv;
  if (command !== 'rerun') throw new RerunError(USAGE);
  const split = rest.indexOf('--');
  const own = split === -1 ? rest : rest.slice(0, split);
  const passthrough = split === -1 ? [] : rest.slice(split + 1);
  /** @type {Record<string, string>} */
  const flags = {};
  for (let i = 0; i < own.length; i += 2) {
    const name = own[i];
    const value = own[i + 1];
    if (name === undefined || !VALUE_FLAGS.includes(name) || value === undefined) throw new RerunError(USAGE);
    flags[name] = value;
  }
  const fromRun = flags['--from-run'];
  if (!fromRun) throw new RerunError(`--from-run is required. ${USAGE}`);
  const scope = flags['--scope'] ?? 'failed';
  if (!SCOPES.includes(scope)) throw new RerunError(`--scope must be one of ${SCOPES.join(', ')}.`);
  return {
    fromRun,
    scope,
    testIds: idList(flags['--test-ids']),
    excludeIds: idList(flags['--exclude-ids']),
    rerunTags: flags['--rerun-tags'],
    passthrough,
  };
}

/** @param {string} text */
function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * The `e2e run` selection for TestDino's lines (`[target] › file › titles…`):
 * the files, the targets, and one anchored --grep per test, since e2e matches
 * a pattern against the describe titles and the test title, space-joined.
 * @param {readonly string[]} testList
 * @returns {string[]}
 */
export function rerunArgs(testList) {
  const files = new Set();
  const targets = new Set();
  const greps = new Set();
  for (const line of testList) {
    const match = /^\[([^\]]+)\] › (.+)$/.exec(line);
    const [file, ...titles] = (match?.[2] ?? '').split(SEPARATOR);
    // Skipping a line would report it as re-run while it never runs.
    if (!match || !file || titles.length === 0) {
      throw new RerunError(`TestDino listed "${line}", which has no test title to select by, so nothing was run.`);
    }
    targets.add(match[1]);
    files.add(file);
    greps.add(`^${escapeRegExp(titles.join(' '))}$`);
  }
  return [...files, '--target', [...targets].join(','), ...[...greps].flatMap((grep) => ['--grep', grep])];
}

/**
 * @param {number} status
 * @param {string | undefined} code
 * @param {string} runId
 * @param {string} url
 */
function describeFailure(status, code, runId, url) {
  if (status >= 500 && !code) return `Could not reach the TestDino API at ${url} (HTTP ${status}).`;
  switch (code) {
    case 'RUN_NOT_FOUND':
      return `Run ${runId} is unknown, belongs to another project, or is not accessible with this token.`;
    case 'RUN_NOT_FINALIZED':
      return `Run ${runId} has not finished yet, so its failed tests are not known.`;
    case 'SELECTION_NOT_READY':
      return `Run ${runId} finished but its results were not processed within ${NOT_READY_BUDGET_MS / 1000}s.`;
    default:
      return `Could not get the failed tests of ${runId} (HTTP ${status}${code ? ` ${code}` : ''}).`;
  }
}

/**
 * @typedef {{ sourceRunId: string; testList: string[]; locations?: string[]; resolution: { selected: number; inScope: number; unrenderableTests?: { title: string }[] } }} Selection
 * @param {{ serverUrl: string; token: string; runId: string; scope: string; testIds: string[]; excludeIds: string[]; fetchImpl: typeof fetch; sleep: (ms: number) => Promise<void>; now: () => number }} options
 * @returns {Promise<Selection>}
 */
async function fetchSelection({ serverUrl, token, runId, scope, testIds, excludeIds, fetchImpl, sleep, now }) {
  const url = `${serverUrl.replace(/\/+$/, '')}/api/v1/reporter/runs/${encodeURIComponent(runId)}/rerun-selection`;
  const deadline = now() + NOT_READY_BUDGET_MS;
  for (;;) {
    /** @type {Response} */
    let response;
    try {
      response = await fetchImpl(url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...(testIds.length > 0 ? { testIds } : { scope }),
          ...(excludeIds.length > 0 && { excludeTestIds: excludeIds }),
        }),
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
    } catch (error) {
      throw new RerunError(`Could not reach ${url}: ${error instanceof Error ? error.message : String(error)}`);
    }
    /** @type {any} */
    const body = await response.json().catch(() => undefined);
    if (response.ok) {
      // A proxy or login page can answer 200 with HTML; never run a list nobody looked at.
      if (!Array.isArray(body?.testList) || typeof body?.resolution?.selected !== 'number') {
        throw new RerunError(`Unexpected response from ${url}: not a re-run selection.`);
      }
      return body;
    }
    const code = typeof body?.error?.code === 'string' ? body.error.code : undefined;
    if (code === 'SELECTION_NOT_READY' && now() < deadline) {
      await sleep(NOT_READY_POLL_MS);
      continue;
    }
    throw new RerunError(describeFailure(response.status, code, runId, url));
  }
}

/**
 * The `e2e run` arguments for a hand-picked selection: the picked tests, written where
 * --last-failed reads them. Its own output folder, so the user's last report stays.
 * @param {readonly string[]} testList
 * @param {readonly string[]} passthrough
 * @param {{ cwd: string; listE2e?: (args: string[]) => Promise<string>; log: (line: string) => void }} io
 * @returns {Promise<string[]>}
 */
async function pickedArgs(testList, passthrough, io) {
  if (passthrough.some((arg) => arg === '--output' || arg.startsWith('--output='))) {
    throw new RerunError('--output cannot be used with picked tests: they need their own output folder.');
  }
  const at = passthrough.indexOf('--config');
  const configArgs = at >= 0 ? passthrough.slice(at, at + 2) : [];
  /** @type {import('./pairs.js').Pair[]} */
  let suite;
  try {
    suite = await listPairs(io, configArgs);
  } catch (error) {
    const why = error instanceof Error ? error.message : String(error);
    throw new RerunError(`The picked tests could not be checked against this checkout (${why}), so nothing ran.`);
  }
  const lines = new Set(testList);
  const wanted = suite.filter((pair) => lines.has(pairLine(pair)));
  if (wanted.length === 0) throw new RerunError('None of the picked tests are on this checkout, so nothing ran.');
  const found = new Set(wanted.map(pairLine));
  const missing = testList.filter((line) => !found.has(line));
  if (missing.length > 0) {
    io.log(
      `TestDino re-run: ${missing.length} picked test(s) are not on this checkout (${missing.slice(0, 5).join(', ')}); running the rest.`
    );
  }
  mkdirSync(join(io.cwd, PICKED_OUTPUT), { recursive: true });
  writeFileSync(join(io.cwd, PICKED_OUTPUT, 'report.json'), JSON.stringify(lastFailedReport(wanted)));
  return ['--last-failed', '--output', PICKED_OUTPUT];
}

/**
 * Runs the command and resolves with its exit code: e2e's own after a re-run,
 * 0 when nothing is left to re-run, 1 when TestDino cannot say what failed.
 * Running the wrong set is worse than stopping, so an error never runs the suite.
 * @param {readonly string[]} argv
 * @param {{
 *   env: Record<string, string | undefined>;
 *   cwd: string;
 *   log: (line: string) => void;
 *   fetchImpl?: typeof fetch;
 *   sleep?: (ms: number) => Promise<void>;
 *   now?: () => number;
 *   platform?: string;
 *   spawnE2e: (args: string[], env: Record<string, string | undefined>) => Promise<number>;
 *   listE2e?: (args: string[]) => Promise<string>;
 * }} io
 * @returns {Promise<number>}
 */
export async function runRerun(argv, io) {
  try {
    const { fromRun, scope, testIds, excludeIds, rerunTags, passthrough } = parseRerunArgs(argv);
    const token = io.env.TESTDINO_TOKEN;
    if (!token) throw new RerunError('TESTDINO_TOKEN is not set: the re-run needs the project API key.');
    const selection = await fetchSelection({
      serverUrl: io.env.TESTDINO_SERVER_URL ?? DEFAULT_SERVER_URL,
      token,
      runId: fromRun,
      scope,
      testIds,
      excludeIds,
      fetchImpl: io.fetchImpl ?? fetch,
      sleep: io.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms))),
      now: io.now ?? Date.now,
    });
    const { selected, inScope, unrenderableTests = [] } = selection.resolution;
    const what = scope.replace(/-/g, ' ');
    if (selected === 0) {
      io.log(`TestDino re-run: nothing to re-run, run ${fromRun} has no ${what} tests.`);
      return 0;
    }
    // e2e takes <file>:<line>, but --grep is not scoped to a file, so a shortened line's
    // prefix pattern can also select unlisted tests in every other selected file.
    if (selection.locations?.length) {
      // A location with a line is a test its title cannot pick; the rest are whole files.
      const placed = selection.locations
        .filter((location) => /:\d+(?::\d+)?$/.test(location))
        .map((location) => location.replace(/\\(.)/g, '$1').replace(/:(\d+):\d+$/, ':$1'));
      throw new RerunError(
        `Some of run ${fromRun}'s tests can only be told apart by file and line (${placed.slice(0, 5).join(', ')}${placed.length > 5 ? ', …' : ''}), which this command cannot select without also running other tests, so nothing was run. Re-run each one with npx e2e run <file>:<line>.`
      );
    }
    const picked = testIds.length > 0 || excludeIds.length > 0;
    const selectionArgs = picked
      ? await pickedArgs(selection.testList, passthrough, io)
      : rerunArgs(selection.testList);
    const args = ['run', ...selectionArgs, ...passthrough];
    if ((io.platform ?? process.platform) === 'win32' && windowsCommandLength(args) > WINDOWS_MAX_COMMAND_CHARS) {
      throw new RerunError(
        `${selected} tests are too many to pass to e2e at once on Windows; re-run a narrower --scope, or from macOS or Linux.`
      );
    }
    io.log(`TestDino re-run: ${selected} of ${inScope} ${what} test(s) from run ${fromRun}.`);
    for (const test of unrenderableTests) {
      io.log(`TestDino re-run: "${test.title}" cannot be selected by title and is not re-run.`);
    }
    return await withTestControls(io, args, {
      ...io.env,
      TESTDINO_RERUN_OF: selection.sourceRunId,
      ...(rerunTags && { TESTDINO_RERUN_TAGS: rerunTags }),
    });
  } catch (error) {
    if (!(error instanceof RerunError)) throw error;
    io.log(`TestDino re-run: ${error.message}`);
    return 1;
  }
}
