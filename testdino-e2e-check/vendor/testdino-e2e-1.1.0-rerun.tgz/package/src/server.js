// @ts-check
// Plain JavaScript so the `testdino-e2e` bin, which runs untranspiled from
// node_modules, can read it as well as the TypeScript reporter.
export const DEFAULT_SERVER_URL = 'https://reporter.testdino.com';
