// @ts-check
// The tests `e2e list --reporter json` names, and the arguments that run exactly them.
// `testdino-e2e run` and `testdino-e2e rerun` share these. Plain JavaScript, as src/rerun.js.
import { createHash } from 'node:crypto';

const SEPARATOR = ' › ';

/**
 * @typedef {{ id?: string; file: string; title?: string; titlePath: string[]; target: string; agent: string; source: { line: number } }} Pair
 */

/**
 * What `e2e list --reporter json` would run. Setup tests are left out: e2e adds the
 * ones a selected test needs by itself, and they are never selected or stored as tests.
 * @param {string} json
 * @returns {Pair[]}
 */
export function listedPairs(json) {
  /** @type {any} */
  const parsed = JSON.parse(json);
  if (!Array.isArray(parsed?.pairs)) throw new Error('e2e list printed no pairs');
  return parsed.pairs.filter(
    /** @param {any} pair */ (pair) => pair.kind !== 'setup' && pair.disposition !== 'filtered'
  );
}

/** @param {Pair} pair TestDino's line for the test: `[target] › file › titles…`. */
export const pairLine = (pair) => `[${pair.target}]${SEPARATOR}${[pair.file, ...pair.titlePath].join(SEPARATOR)}`;

/**
 * The `e2e run` arguments for exactly these tests. `file:line` picks a test by
 * where it is declared, so equal titles in other files are not pulled in; --target
 * applies to all of them, which the exact check after it catches.
 * @param {readonly Pair[]} pairs
 */
export function pairArgs(pairs) {
  const locations = new Set(pairs.map((pair) => `${pair.file}:${pair.source.line}`));
  const targets = new Set(pairs.map((pair) => pair.target));
  return [...locations, '--target', [...targets].join(',')];
}

/**
 * The tests these arguments would run, by id. --pass-with-no-tests, because e2e
 * otherwise exits 2 on an empty list and "nothing found" reads as a failed check.
 * @param {{ listE2e?: (args: string[]) => Promise<string> }} io
 * @param {string[]} args
 */
export async function listPairs(io, args) {
  if (!io.listE2e) throw new Error('e2e list is not available');
  return listedPairs(await io.listE2e([...args, '--pass-with-no-tests']));
}

/**
 * Tests the arguments would run beyond `wanted`, and wanted ones they would miss.
 * @param {readonly Pair[]} listed
 * @param {readonly Pair[]} wanted
 */
export function compareIds(listed, wanted) {
  const wantedIds = new Set(wanted.map(pairWireId));
  const listedIds = new Set(listed.map(pairWireId));
  return {
    extra: listed.filter((pair) => !wantedIds.has(pairWireId(pair))),
    absent: wanted.filter((pair) => !listedIds.has(pairWireId(pair))),
  };
}

/**
 * e2e's test id: `file::title::title`, each title percent-encoded as its
 * internal/ids.js encodeTitle does.
 * @param {{ file: string; titlePath: string[] }} pair
 */
function pairTestId(pair) {
  const encode = (/** @type {string} */ title) => {
    let out = '';
    for (const byte of new TextEncoder().encode(title.normalize('NFC'))) {
      const ch = String.fromCharCode(byte);
      out += /[A-Za-z0-9\-._~]/.test(ch) && byte < 0x80 ? ch : `%${byte.toString(16).toUpperCase().padStart(2, '0')}`;
    }
    return out;
  };
  return `${pair.file}::${pair.titlePath.map(encode).join('::')}`;
}

/**
 * e2e's test id hashed with the target, agent and repeat as the reporter's
 * wireTestId does: the id TestDino stored for the test.
 * @param {{ file: string; titlePath: string[]; target: string; agent: string }} pair
 */
export function pairWireId(pair) {
  return createHash('sha1')
    .update([pair.target, pair.agent, '0', pairTestId(pair)].join('\u0000'))
    .digest('hex');
}

/**
 * The report `e2e run --last-failed` reads, naming exactly these tests. It is e2e's only
 * selection by test and target together, as Playwright's --test-list is. e2e rejects a
 * report it cannot read, and the filter only narrows, so a change to it cannot add tests.
 * @param {readonly Pair[]} pairs
 */
export function lastFailedReport(pairs) {
  const results = pairs.map((pair) => ({
    id: pair.id,
    testId: pairTestId(pair),
    targetId: pair.target,
    agent: pair.agent,
    file: pair.file,
    titlePath: pair.titlePath,
    status: 'failed',
    attempts: [],
  }));
  return { schemaVersion: 'report-1', run: { results, errors: [], serialGroups: [] } };
}
