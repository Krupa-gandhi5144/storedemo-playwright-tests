// @ts-check
// `testdino-e2e run`: runs `e2e run` and adds what a reporter cannot do:
// - its exit code: Test Controls decides the build result as it does for Playwright;
// - `--selection <id>`: runs exactly a test selection stored in TestDino;
// - on a GitHub Actions retry, runs only the tests of this job that failed
//   before, when the dashboard asked for it (root docs/RERUN_FAILED_TESTS.md §14).
//
// Plain JavaScript for the reason src/rerun.js gives.
import { compareIds, listPairs, pairArgs, pairLine, pairWireId } from './pairs.js';

/** @typedef {import('./pairs.js').Pair} Pair */
import { RerunError, WINDOWS_MAX_COMMAND_CHARS, withTestControls, windowsCommandLength } from './rerun.js';
import { DEFAULT_SERVER_URL } from './server.js';

const USAGE = 'Usage: testdino-e2e run [--selection <id>] [-- <e2e run options>]';
const REQUEST_TIMEOUT_MS = 15_000;
const REPORT_TIMEOUT_MS = 5_000;
// The outcome endpoint keeps at most this many missing tests.
const MAX_REPORTED_NOT_FOUND = 50;
const COMMIT_PATTERN = /^[0-9a-f]{7,64}$/;

// With --selection the selection decides which tests run, so only options that
// change how they run are allowed, and --shard, which splits them across jobs:
// e2e ORs a file or --grep into the selection instead of narrowing it. Each takes
// a value, takes none, or an optional mode.
const VALUE_OPTIONS = new Set([
  '--config',
  '--workers',
  '--retries',
  '--action-timeout',
  '--assertion-timeout',
  '--max-failures',
  '--max-duration',
  '--reporter',
  '--output',
  '--cache-dir',
  '--shard',
]);
const FLAG_OPTIONS = new Set([
  '--headed',
  '--no-cache',
  '--strict-cache',
  '-u',
  '--update-snapshots',
  '--debug',
  '--ai-trace',
  '--pass-with-no-tests',
]);
const MODE_OPTIONS = new Set(['--trace', '--video']);
// The options `e2e list` shares with `e2e run`: what they select is what a retry narrows.
const SELECTION_VALUE_OPTIONS = new Set([
  '--config',
  '--target',
  '--grep',
  '--grep-invert',
  '--tag',
  '--tag-mode',
  '--exclude-tag',
  '--changed-since',
  '--shard',
]);
const SELECTION_FLAG_OPTIONS = new Set(['--last-failed', '--pass-with-no-tests']);
const CI_RERUN_PATH = '/api/v1/reporter/ci-reruns/selection';
const PIPELINE_ID = /^[0-9]{1,20}$/;
const NOT_READY_BUDGET_MS = 90_000;
const NOT_READY_POLL_MS = 2_000;
const RECORDING_MODES = new Set(['off', 'on', 'retain-on-failure', 'on-first-retry', 'on-all-retries']);

export { listedPairs, pairWireId } from './pairs.js';

export class RunError extends Error {}

/**
 * @param {readonly string[]} argv the arguments after the program name
 * @returns {{ selection: string | undefined; passthrough: string[] }}
 */
export function parseRunArgs(argv) {
  const [command, ...rest] = argv;
  if (command !== 'run') throw new RunError(USAGE);
  const split = rest.indexOf('--');
  const own = split === -1 ? rest : rest.slice(0, split);
  const passthrough = split === -1 ? [] : rest.slice(split + 1);
  /** @type {string | undefined} */
  let selection;
  for (let i = 0; i < own.length; i += 2) {
    if (own[i] !== '--selection' || !own[i + 1]) {
      throw new RunError(`Unknown option ${own[i]}. Put e2e's own options after --. ${USAGE}`);
    }
    selection = own[i + 1];
  }
  return { selection, passthrough };
}

/**
 * Refuses an option that could change which tests run, and returns `--config`'s
 * value, since the selection check must collect tests from the same config, and
 * whether the job is sharded.
 * @param {readonly string[]} passthrough
 * @returns {{ config: string | undefined; sharded: boolean }}
 */
export function checkSelectionPassthrough(passthrough) {
  /** @type {string | undefined} */
  let config;
  let sharded = false;
  for (let i = 0; i < passthrough.length; i++) {
    const arg = passthrough[i] ?? '';
    const [name = '', inline] = arg.startsWith('--') ? arg.split(/=(.*)/s) : [arg];
    if (VALUE_OPTIONS.has(name)) {
      const value = inline ?? passthrough[++i];
      if (value === undefined) throw new RunError(`${name} needs a value.`);
      if (name === '--config') config = value;
      if (name === '--shard') sharded = true;
    } else if (MODE_OPTIONS.has(name)) {
      if (inline === undefined && RECORDING_MODES.has(passthrough[i + 1] ?? '')) i++;
    } else if (!FLAG_OPTIONS.has(name) || inline !== undefined) {
      throw new RunError(
        `--selection decides which tests run, so "${arg}" cannot be added; only options that change how they run can (${[...VALUE_OPTIONS, ...FLAG_OPTIONS, ...MODE_OPTIONS].join(', ')}).`
      );
    }
  }
  return { config, sharded };
}

/**
 * @typedef {{ testId: string; line: string }} SelectionEntry
 * @typedef {{ selectionId: string; onMissing: 'skip' | 'fail'; entries: SelectionEntry[]; unrenderable: { title: string }[]; unknownTestIds: string[] }} TestSelection
 * @typedef {{ serverUrl: string; token: string; selectionId: string; fetchImpl: typeof fetch }} Api
 */

/** @param {Api} api */
const selectionUrl = (api) =>
  `${api.serverUrl.replace(/\/+$/, '')}/api/v1/reporter/test-selections/${encodeURIComponent(api.selectionId)}`;

/**
 * Every failure is terminal: running anything but the stored selection, such as
 * the whole suite, would report a run nobody asked for.
 * @param {Api} api
 * @returns {Promise<TestSelection>}
 */
async function fetchSelection(api) {
  const url = selectionUrl(api);
  /** @type {Response} */
  let response;
  try {
    response = await api.fetchImpl(url, {
      headers: { Authorization: `Bearer ${api.token}` },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch (error) {
    throw new RunError(
      `Could not fetch selection ${api.selectionId} from ${url}: ${error instanceof Error ? error.message : String(error)}. Nothing was run.`
    );
  }
  /** @type {any} */
  const body = await response.json().catch(() => undefined);
  if (!response.ok) {
    const code = typeof body?.error?.code === 'string' ? ` ${body.error.code}` : '';
    if (response.status === 404) {
      throw new RunError(
        `Selection ${api.selectionId} is unknown, belongs to another project, or is not accessible with this token. Nothing was run.`
      );
    }
    throw new RunError(
      `Could not fetch selection ${api.selectionId} (HTTP ${response.status}${code}). Nothing was run.`
    );
  }
  // A proxy or login page can answer 200 with HTML or another JSON shape.
  const valid =
    (body?.onMissing === 'skip' || body?.onMissing === 'fail') &&
    Array.isArray(body?.entries) &&
    body.entries.every(/** @param {any} e */ (e) => typeof e?.testId === 'string' && typeof e?.line === 'string');
  if (!valid) throw new RunError(`Unexpected response from ${url}: not a test selection. Nothing was run.`);
  return {
    selectionId: api.selectionId,
    onMissing: body.onMissing,
    entries: body.entries,
    unrenderable: Array.isArray(body.unrenderable) ? body.unrenderable : [],
    unknownTestIds: Array.isArray(body.unknownTestIds) ? body.unknownTestIds : [],
  };
}

/**
 * Tells TestDino why a selection ran nothing; no test run exists then, so this is
 * the run page's only source. Best effort.
 * @param {Api} api
 * @param {{ reason: 'none_found' | 'check_failed' | 'overshoot'; requested: number; notFound: SelectionEntry[]; env: Record<string, string | undefined> }} outcome
 */
async function reportNothingRan(api, { reason, requested, notFound, env }) {
  // A TestDino-started run is a workflow_dispatch: GITHUB_SHA and GITHUB_REF_NAME are the branch head that ran.
  const commit = env.GITHUB_SHA?.toLowerCase();
  const branch = env.GITHUB_REF_NAME;
  try {
    const response = await api.fetchImpl(`${selectionUrl(api)}/outcome`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${api.token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reason,
        requested,
        notFound: notFound.slice(0, MAX_REPORTED_NOT_FOUND).map(({ testId, line }) => ({ testId, line })),
        ...(branch && { branch }),
        ...(commit && COMMIT_PATTERN.test(commit) && { commit }),
      }),
      signal: AbortSignal.timeout(REPORT_TIMEOUT_MS),
    });
    return response.ok;
  } catch {
    return false;
  }
}

/**
 * Splits `e2e run` options into those that select tests (and `e2e list` takes)
 * and those that only change how they run. Undefined when an option is unknown
 * or changes the tests' ids (--agent, --repeat-each): a retry then runs in full.
 * @param {readonly string[]} args
 * @returns {{ select: string[]; runOnly: string[]; config: string[]; shard: string | undefined } | undefined}
 */
export function splitRunOptions(args) {
  /** @type {string[]} */ const select = [];
  /** @type {string[]} */ const runOnly = [];
  /** @type {string[]} */ const config = [];
  /** @type {string | undefined} */ let shard;
  for (let i = 0; i < args.length; i++) {
    const arg = args[i] ?? '';
    const [name = '', inline] = arg.startsWith('--') ? arg.split(/=(.*)/s) : [arg];
    const take = () => (inline === undefined ? args[++i] : undefined);
    if (!arg.startsWith('-')) {
      select.push(arg);
    } else if (SELECTION_VALUE_OPTIONS.has(name)) {
      const value = inline ?? take();
      if (value === undefined) return undefined;
      if (name === '--shard') shard = value;
      else if (name === '--config') config.push(name, value);
      else select.push(name, value);
    } else if (SELECTION_FLAG_OPTIONS.has(name) && inline === undefined) {
      select.push(arg);
    } else if (VALUE_OPTIONS.has(name)) {
      const value = inline ?? take();
      if (value === undefined) return undefined;
      if (name === '--config') config.push(name, value);
      else runOnly.push(name, value);
    } else if (MODE_OPTIONS.has(name)) {
      runOnly.push(arg);
      if (inline === undefined && RECORDING_MODES.has(args[i + 1] ?? '')) runOnly.push(args[++i] ?? '');
    } else if (FLAG_OPTIONS.has(name) && inline === undefined) {
      runOnly.push(arg);
    } else {
      return undefined;
    }
  }
  return { select, runOnly, config, shard };
}

/** @param {string | undefined} reason the door's answer when it does not narrow */
function describeReason(reason) {
  switch (reason) {
    case 'NO_INTENT':
      return 'this retry was not started from TestDino';
    case 'NOTHING_FAILED':
      return 'none of these tests failed in the earlier attempt';
    case 'NOT_COVERED':
      return 'some of these tests did not run in the earlier attempt';
    case 'MULTIPLE_SOURCES':
      return 'the earlier failures span more than one TestDino run';
    case 'MULTIPLE_JOBS':
      return 'these tests also ran in another job of the earlier attempt';
    case 'TOO_MANY_TESTS':
      return 'the suite is too large to narrow';
    default:
      return reason ? `TestDino answered ${reason}` : 'TestDino gave no reason';
  }
}

/**
 * On a GitHub Actions retry, the arguments that run only this job's tests that
 * failed before. Never throws: every doubt runs the job in full, since a retry
 * that turns green on a partial run would hide a failure.
 * @param {string[]} passthrough
 * @param {string[] | undefined} selectionArgs a --selection job's own arguments
 * @param {RunIo} io
 * @returns {Promise<{ args?: string[]; env: Record<string, string> } | undefined>}
 */
async function narrowRetry(passthrough, selectionArgs, io) {
  const { env } = io;
  const attempt = Number(env.GITHUB_RUN_ATTEMPT);
  const pipelineId = env.GITHUB_RUN_ID ?? '';
  const token = env.TESTDINO_TOKEN;
  if (
    env.GITHUB_ACTIONS !== 'true' ||
    !Number.isInteger(attempt) ||
    attempt < 2 ||
    !PIPELINE_ID.test(pipelineId) ||
    !token
  ) {
    return undefined;
  }
  // The door names the run this retry came from even when it refuses, so a full run stays linked to it.
  const full = (/** @type {string} */ why, /** @type {unknown} */ sourceRunId = undefined) => {
    io.log(`TestDino re-run: running this job in full (${why}).`);
    return typeof sourceRunId === 'string' ? { env: { TESTDINO_RERUN_OF: sourceRunId } } : undefined;
  };
  const options = splitRunOptions(passthrough);
  if (!options) return full('an e2e option it cannot narrow safely');
  const fetchImpl = io.fetchImpl ?? fetch;
  const sleep = io.sleep ?? ((/** @type {number} */ ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const now = io.now ?? Date.now;
  try {
    const shardArgs = options.shard ? ['--shard', options.shard] : [];
    const pairs = await listPairs(io, [...(selectionArgs ?? options.select), ...options.config, ...shardArgs]);
    const url = `${(env.TESTDINO_SERVER_URL ?? DEFAULT_SERVER_URL).replace(/\/+$/, '')}${CI_RERUN_PATH}`;
    const body = JSON.stringify({ pipelineId, attempt, testIds: pairs.map(pairWireId) });
    const deadline = now() + NOT_READY_BUDGET_MS;
    /** @type {any} */
    let answer;
    for (;;) {
      const response = await fetchImpl(url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body,
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });
      answer = await response.json().catch(() => undefined);
      if (response.ok && answer) break;
      const code = answer?.error?.code;
      if (code === 'SELECTION_NOT_READY' && now() < deadline) {
        await sleep(NOT_READY_POLL_MS);
        continue;
      }
      return full(`TestDino answered HTTP ${response.status}${code ? ` ${code}` : ''}`);
    }
    if (answer.narrow !== true) return full(describeReason(answer.reason), answer.sourceRunId);
    if (!Array.isArray(answer.testList) || answer.testList.length === 0 || typeof answer.sourceRunId !== 'string') {
      return full('TestDino answered without a selection', answer.sourceRunId);
    }
    const failed = new Set(answer.testList);
    const wanted = pairs.filter((pair) => failed.has(pairLine(pair)));
    if (new Set(wanted.map(pairLine)).size !== failed.size) {
      return full('some failed tests are not in this job', answer.sourceRunId);
    }
    const args = pairArgs(wanted);
    // The retry must run exactly the failed tests, nothing more, nothing less.
    const { extra, absent } = compareIds(await listPairs(io, [...args, ...options.config]), wanted);
    if (extra.length > 0 || absent.length > 0) {
      return full('the failed tests could not be selected exactly', answer.sourceRunId);
    }
    io.log(`TestDino re-run: attempt ${attempt} runs the ${wanted.length} test(s) this job failed before.`);
    return {
      args: [...args, ...options.config, ...options.runOnly],
      // The job keeps its own shard, so the attempt's jobs still group into one run.
      env: { TESTDINO_RERUN_OF: answer.sourceRunId, ...(options.shard && { TESTDINO_SHARD: options.shard }) },
    };
  } catch (error) {
    return full(error instanceof Error ? error.message : String(error));
  }
}

/**
 * @typedef {{
 *   env: Record<string, string | undefined>;
 *   log: (line: string) => void;
 *   fetchImpl?: typeof fetch;
 *   spawnE2e: (args: string[], env: Record<string, string | undefined>) => Promise<number>;
 *   listE2e?: (args: string[]) => Promise<string>;
 *   sleep?: (ms: number) => Promise<void>;
 *   now?: () => number;
 *   platform?: string;
 * }} RunIo
 */

/**
 * Checks the selection against this checkout and returns the e2e arguments that
 * run what matched, with the report the reporter sends on run:begin.
 * @param {string} selectionId
 * @param {string[]} passthrough
 * @param {RunIo} io
 */
async function prepareSelection(selectionId, passthrough, io) {
  const token = io.env.TESTDINO_TOKEN;
  if (!token) throw new RunError('TESTDINO_TOKEN is not set: --selection needs the project API key.');
  const api = {
    serverUrl: io.env.TESTDINO_SERVER_URL ?? DEFAULT_SERVER_URL,
    token,
    selectionId,
    fetchImpl: io.fetchImpl ?? fetch,
  };
  const selection = await fetchSelection(api);
  const { entries } = selection;
  for (const test of selection.unrenderable) {
    io.log(`TestDino selection: "${test.title}" cannot be selected and is not run.`);
  }
  if (selection.unknownTestIds.length > 0) {
    io.log(
      `TestDino selection: ${selection.unknownTestIds.length} selected test(s) are unknown to TestDino and not run.`
    );
  }
  if (entries.length === 0) throw new RunError(`Selection ${selectionId} has no test that can be run, so nothing ran.`);

  /**
   * @param {'none_found' | 'check_failed' | 'overshoot'} reason
   * @param {SelectionEntry[]} notFound
   * @param {string} message
   * @returns {Promise<never>}
   */
  const stop = async (reason, notFound, message) => {
    if (!(await reportNothingRan(api, { reason, requested: entries.length, notFound, env: io.env }))) {
      io.log('TestDino selection: could not tell TestDino that nothing ran; its run page will keep waiting.');
    }
    throw new RunError(message);
  };

  if (io.env.TESTDINO_SPLIT || io.env.TESTDINO_SPLIT_ID) {
    return stop(
      'check_failed',
      [],
      '--selection cannot be combined with a split: every job would run the whole selection.'
    );
  }
  /** @type {ReturnType<typeof checkSelectionPassthrough>} */
  let options;
  try {
    options = checkSelectionPassthrough(passthrough);
  } catch (error) {
    return stop('check_failed', [], error instanceof Error ? error.message : String(error));
  }
  const configArgs = options.config ? ['--config', options.config] : [];

  // One listing of the whole suite, matched by line, with the stored id telling a
  // test's agents apart. Past repeats share their test's line.
  /** @type {Pair[]} */
  let suite;
  try {
    suite = await listPairs(io, configArgs);
  } catch (error) {
    // The check is what makes the selection safe; without it nothing runs.
    return stop(
      'check_failed',
      [],
      `Selection ${selectionId} could not be checked against this checkout (${error instanceof Error ? error.message : String(error)}), so nothing ran.`
    );
  }
  const byId = new Map(suite.map((pair) => [pairWireId(pair), pair]));
  /** @type {Map<string, Pair[]>} */
  const byLine = new Map();
  for (const pair of suite) byLine.set(pairLine(pair), [...(byLine.get(pairLine(pair)) ?? []), pair]);
  // The line names the target: TestDino sends one id for a test with a line per target.
  const find = (/** @type {SelectionEntry} */ entry) => {
    const sameLine = byLine.get(entry.line) ?? [];
    if (sameLine.length === 1) return sameLine[0];
    const pair = byId.get(entry.testId);
    if (sameLine.length > 1) return sameLine.find((candidate) => candidate === pair);
    return pair && entry.line.startsWith(`[${pair.target}]`) ? pair : undefined;
  };
  const missing = entries.filter((entry) => !find(entry));
  const wanted = [...new Set(entries.flatMap((entry) => find(entry) ?? []))];
  if (wanted.length === 0) {
    return stop(
      'none_found',
      missing,
      entries.length === 1
        ? 'The selected test was not found, so nothing ran.'
        : `None of the ${entries.length} selected tests were found, so nothing ran.`
    );
  }

  const args = pairArgs(wanted);
  /** @type {ReturnType<typeof compareIds>} */
  let difference;
  try {
    difference = compareIds(await listPairs(io, [...args, ...configArgs]), wanted);
  } catch (error) {
    return stop(
      'check_failed',
      [],
      `Selection ${selectionId} could not be checked against this checkout (${error instanceof Error ? error.message : String(error)}), so nothing ran.`
    );
  }
  if (difference.extra.length > 0) {
    const names = difference.extra.slice(0, 5).map(pairLine);
    return stop(
      'overshoot',
      [],
      `Selection ${selectionId} would also run tests that were not selected (${names.join(', ')}${difference.extra.length > 5 ? ', …' : ''}), so nothing ran.`
    );
  }
  if (difference.absent.length > 0) {
    return stop(
      'check_failed',
      [],
      `Selection ${selectionId} could not pick out ${difference.absent.length} of its tests, so nothing ran.`
    );
  }
  if (
    (io.platform ?? process.platform) === 'win32' &&
    windowsCommandLength(['run', ...args]) > WINDOWS_MAX_COMMAND_CHARS
  ) {
    return stop('check_failed', [], `Selection ${selectionId} is too large to pass to e2e on Windows, so nothing ran.`);
  }
  if (missing.length > 0) {
    const verdict = selection.onMissing === 'fail' ? 'then failing the run' : 'and skipping the missing ones';
    io.log(
      `TestDino selection: ${missing.length} of ${entries.length} selected tests are not on this checkout (${missing
        .slice(0, 5)
        .map((entry) => entry.line)
        .join(', ')}); running the rest, ${verdict}.`
    );
  }
  const matched = entries.length - missing.length;
  io.log(`TestDino selection ${selectionId}: running ${matched} of ${entries.length} selected tests.`);
  const report = {
    id: selectionId,
    onMissing: selection.onMissing,
    requested: entries.length,
    matched,
    notFound: missing.slice(0, MAX_REPORTED_NOT_FOUND).map(({ testId, line }) => ({ testId, line })),
  };
  return {
    // A shard whose part of the selection is empty is not a failure.
    args: options.sharded ? [...args, '--pass-with-no-tests'] : args,
    report,
    failForMissing: selection.onMissing === 'fail' && missing.length > 0,
  };
}

/**
 * @param {readonly string[]} argv
 * @param {RunIo} io
 * @returns {Promise<number>}
 */
export async function runRun(argv, io) {
  try {
    const { selection, passthrough } = parseRunArgs(argv);
    const prepared = selection ? await prepareSelection(selection, passthrough, io) : undefined;
    const retry = await narrowRetry(passthrough, prepared?.args, io);
    const args = retry?.args ?? [...(prepared?.args ?? []), ...passthrough];
    const exitCode = await withTestControls(io, ['run', ...args], {
      ...io.env,
      ...(prepared && { TESTDINO_SELECTION: JSON.stringify(prepared.report) }),
      ...retry?.env,
    });
    if (prepared?.failForMissing && exitCode === 0) {
      io.log('TestDino selection: failing the run because selected tests are not on this checkout.');
      return 1;
    }
    return exitCode;
  } catch (error) {
    if (!(error instanceof RunError) && !(error instanceof RerunError)) throw error;
    io.log(`TestDino: ${error.message}`);
    return 1;
  }
}
