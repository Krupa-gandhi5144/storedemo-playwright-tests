// Ingestion treats a live run as idle after 2 minutes without an event and
// expects at most 90 s between them; a single long test can send nothing that
// long. Polling every 30 s for 60 s of silence keeps the gap under 90 s.
export const HEARTBEAT_POLL_MS = 30_000;
export const HEARTBEAT_SILENCE_MS = 60_000;

export interface Heartbeat {
  /** Something reached the server; the silence starts again. */
  sent(): void;
  stop(): void;
}

/** Calls `beat` once nothing was sent for HEARTBEAT_SILENCE_MS, checking every HEARTBEAT_POLL_MS. */
export function startHeartbeat(beat: () => void, now: () => number = Date.now): Heartbeat {
  let last = now();
  const timer = setInterval(() => {
    if (now() - last < HEARTBEAT_SILENCE_MS) return;
    last = now();
    beat();
  }, HEARTBEAT_POLL_MS);
  // The heartbeat never keeps e2e's process alive on its own.
  timer.unref();
  return {
    sent: () => {
      last = now();
    },
    stop: () => clearInterval(timer),
  };
}
