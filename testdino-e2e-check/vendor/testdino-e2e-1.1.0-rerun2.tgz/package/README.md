# @testdino/e2e

[![npm version](https://img.shields.io/npm/v/@testdino/e2e.svg)](https://www.npmjs.com/package/@testdino/e2e)
[![npm downloads](https://img.shields.io/npm/dm/@testdino/e2e.svg)](https://www.npmjs.com/package/@testdino/e2e)
[![Node.js](https://img.shields.io/badge/Node.js-%3E%3D22.12.0-green.svg)](https://nodejs.org/)

TestDino reporter for the [e2e framework by TesterArmy](https://github.com/tester-army/e2e). Each `e2e run` appears on your TestDino dashboard while it runs, with its test cases, retries, steps, errors, console output, screenshots, and videos.

<p align="center">
  <img width="830" src="https://tdstorageus.blob.core.windows.net/public/thumbnail/e2e-reporter-thumbnail.webp" alt="TestDino e2e reporter: every e2e test run on TestDino while it runs" />
</p>

**[Website](https://www.testdino.com)** | **[Documentation](https://docs.testdino.com/cli/testdino-e2e)** | **[Get Your Token](https://docs.testdino.com/guides/generate-api-keys#create-an-api-key)** | **[Changelog](https://changelog.testdino.com/?type=cli)** | **[Support](mailto:support@testdino.com)**

Using Playwright? Install [`@testdino/playwright`](https://www.npmjs.com/package/@testdino/playwright) instead.

## Quick start

**Requirements:** Node.js >= 22.12.0, `e2e` >= 0.16.0 and < 1. If you type-check your project with `tsc`, also install `@types/node`.

**1.** Install the reporter:

```bash
npm install --save-dev @testdino/e2e
```

**2.** Add it to the `reporters` in your e2e config. Keep any other reporters you use, such as `list`.

```typescript
// e2e.config.ts
import type { E2EConfig } from 'e2e';
import { testdino } from '@testdino/e2e';

export default {
  targets: [
    /* your targets */
  ],
  reporters: ['list', testdino()],
} satisfies E2EConfig;
```

**3.** Set your token and run your tests:

```bash
export TESTDINO_TOKEN="your-token"
npx e2e run
```

When the run finishes, the `TestDino` line of the e2e output shows a link to the test run.

## Configuration

Pass options to `testdino()`. An option set in the config takes precedence over its environment variable.

| Option      | Environment variable | Description                                                              |
| ----------- | -------------------- | ------------------------------------------------------------------------ |
| `token`     | `TESTDINO_TOKEN`     | Project API key. Without it, the reporter uploads nothing.               |
| `ciRunId`   | `TESTDINO_CI_RUN_ID` | Merges the shards of one run into a single test run.                     |
| `split`     | `TESTDINO_SPLIT`     | Split position, for example `2/3`. Needs `splitId`.                      |
| `splitId`   | `TESTDINO_SPLIT_ID`  | ID shared by every job of one split run.                                 |
| `tags`      | `TESTDINO_TAGS`      | Run-level tags, for example `['nightly']`; env is comma-separated.       |
| `artifacts` | None                 | Uploads screenshots, videos, and traces. Set `false` to keep them local. |
| `debug`     | `TESTDINO_DEBUG`     | Set `true` (or `1`) to print what the reporter does to stderr.           |

```typescript
reporters: ['list', testdino({ tags: ['nightly'], artifacts: false })],
```

## CI/CD integration

### GitHub Actions

```yaml
- name: Run e2e tests
  run: npx e2e run
  env:
    TESTDINO_TOKEN: ${{ secrets.TESTDINO_TOKEN }}
```

On a `pull_request` event, the test run carries the PR number, branches, and author.

### Sharded execution

Set the same `TESTDINO_CI_RUN_ID` on every shard. TestDino merges the shards into 1 test run.

```bash
TESTDINO_CI_RUN_ID="$CI_RUN_ID" npx e2e run --shard 1/2
TESTDINO_CI_RUN_ID="$CI_RUN_ID" npx e2e run --shard 2/2
```

On GitHub Actions, use `${{ github.run_id }}-${{ github.run_attempt }}` as the ID. A shard started without `TESTDINO_CI_RUN_ID` uploads as its own test run.

### Split execution

When each job runs different files, give every job its position and the same split ID. TestDino merges the jobs into 1 test run. Set both variables.

```bash
TESTDINO_SPLIT=1/2 TESTDINO_SPLIT_ID="$SPLIT_ID" npx e2e run tests/checkout.e2e.ts
TESTDINO_SPLIT=2/2 TESTDINO_SPLIT_ID="$SPLIT_ID" npx e2e run tests/login.e2e.ts
```

## Run through TestDino in CI

`testdino-e2e run` runs `e2e run` and adds what a reporter cannot do on its own. Use it in CI in place of `npx e2e run`; put e2e's own options after `--`:

```yaml
- name: Run e2e tests
  run: npx -p @testdino/e2e testdino-e2e run -- --workers 2
  env:
    TESTDINO_TOKEN: ${{ secrets.TESTDINO_TOKEN }}
```

- **Test Controls decide the build result.** A run whose only failures are quarantined, or match a known error, exits 0. A critical test that passed only on retry exits 1. Exit codes 2, 3, 4 and 130 are never changed. With plain `npx e2e run`, Test Controls do not change the exit code.
- **A GitHub Actions retry runs only what failed.** When you re-run a test run's failures from TestDino, each retried job runs only its own tests that failed before. A job that cannot be narrowed safely, for example one passing `--repeat-each` or an option the command does not know, runs in full and says why.
- **Run a stored test selection** with `--selection <id>`, as TestDino's **Run automated tests** does:

  ```bash
  npx -p @testdino/e2e testdino-e2e run --selection "$TD_SELECTION"
  ```

  The selection is checked against your checkout with `e2e list` first. A selection that would also run tests that were not selected, or none of whose tests exist, runs nothing and tells TestDino why. Missing tests are skipped, or fail the job after the rest ran, as the selection says. With `--selection`, options after `--` can change only how tests run (such as `--workers`, `--retries`, `--headed`, `--trace`, `--config`) or spread them across jobs with `--shard`, never which ones run. A selection cannot run in a split job.

## Re-run failed tests

Run again only the tests that failed in a TestDino test run. Run it from the folder with your `e2e.config.ts`, with `TESTDINO_TOKEN` set:

```bash
npx -p @testdino/e2e testdino-e2e rerun --from-run <testRunId>
```

`-p @testdino/e2e` makes npx use this package, never an unrelated package called `testdino-e2e`.

The command does not read `e2e.config.ts`: if your reporter sets `serverUrl`, set `TESTDINO_SERVER_URL` to the same address for the re-run.

| Option          | Default  | Description                                               |
| --------------- | -------- | --------------------------------------------------------- |
| `--from-run`    | None     | The TestDino test run whose tests to run again. Required. |
| `--scope`       | `failed` | `failed`, `flaky`, or `failed-and-flaky`.                 |
| `--test-ids`    | None     | Comma-separated test ids to run instead of the scope.     |
| `--exclude-ids` | None     | Comma-separated test ids to leave out of the scope.       |
| `--rerun-tags`  | None     | Comma-separated tags to add to the re-run.                |
| `-- <options>`  | None     | Passed to `e2e run`, for example `-- --workers 2`.        |

- The new test run appears in TestDino as a re-run of the original.
- `--rerun-tags a,b` or `TESTDINO_RERUN_TAGS=a,b` adds tags to the re-run, on top of its run tags.
- Exactly the selected tests run, each on its own target. Their results go to `.e2e/testdino-picked`, so your last report stays; `-- --output <dir>` uses your folder instead.
- The selection is checked against your checkout first, as `tdpw test --rerun` does. Tests that are not on it are skipped and named. If none are, the command exits 1 and nothing runs.
- `--grep`, `--grep-invert`, `--last-failed`, `--changed-since` and `--shard` are refused, because the selection already decides which tests run.
- Nothing to re-run exits 0 without starting e2e. If TestDino cannot say which tests failed, or `e2e list` cannot check the selection, the command exits 1 and runs nothing.
- Ctrl+C or `docker stop` stops the re-run's tests too.

### Start a re-run from TestDino

To re-run on the latest commit, on another branch, or with hand-picked tests from TestDino, declare the re-run inputs on a workflow and pass them to the command:

```yaml
on:
  workflow_dispatch:
    inputs:
      testdino_rerun_from: { required: false }
      testdino_rerun_scope: { required: false }
      testdino_rerun_test_ids: { required: false }
      testdino_rerun_exclude_ids: { required: false }
      testdino_rerun_tags: { required: false }
jobs:
  test:
    steps:
      - uses: actions/checkout@v4
      - name: Run tests
        env:
          TESTDINO_TOKEN: ${{ secrets.TESTDINO_TOKEN }}
          TD_FROM: ${{ inputs.testdino_rerun_from }}
          TD_SCOPE: ${{ inputs.testdino_rerun_scope }}
          TD_IDS: ${{ inputs.testdino_rerun_test_ids }}
          TD_EXCLUDE: ${{ inputs.testdino_rerun_exclude_ids }}
          TD_TAGS: ${{ inputs.testdino_rerun_tags }}
        shell: bash
        run: |
          if [ -z "$TD_FROM" ]; then
            npx -p @testdino/e2e testdino-e2e run
            exit
          fi
          args=(--from-run "$TD_FROM" --scope "${TD_SCOPE:-failed}")
          [ -n "$TD_IDS" ] && args+=(--test-ids "$TD_IDS")
          [ -n "$TD_EXCLUDE" ] && args+=(--exclude-ids "$TD_EXCLUDE")
          [ -n "$TD_TAGS" ] && args+=(--rerun-tags "$TD_TAGS")
          npx -p @testdino/e2e testdino-e2e rerun "${args[@]}"
```

## Differences from Playwright test runs

- **Tests appear as each one starts.** The test run shows as running from the start, with its total, and each test is listed as running while it runs. Unlike a Playwright run, tests that have not started yet are not listed, and a test's steps, errors and retries appear when it finishes.
- **Targets are shown as projects.** The test run's Configuration tab lists them under **Targets**.
- **Pull request status:** a run shows its pull request on every CI the Playwright reporter supports, but a Bitbucket run after the pull request merged is not marked merged.
- **Failure details:** a failed test's error also shows the page address (without any password, query string or fragment), the screen size, the elements closest to what a locator looked for when it found nothing, and the AI's judgment when a model checked the step.
- **App logs:** what the app logged during a test (its console, uncaught errors, network warnings) appears in the test's **Console**, with the step it happened in. Errors appear as `stderr`, everything else as `stdout`. The newest 200 lines per attempt are kept; URLs lose any password, query string and fragment.
- **Artifacts:** PNG, JPEG, WebM, MP4, ZIP, JSON, TXT, and Markdown files up to 50 MB each. A device recording over 50 MB, or one a hosted device service keeps as a link, is listed as not uploaded. A test's artifacts upload when the test finishes. Anything still uploading 40 seconds after the run finishes is not uploaded, so the test run is always completed.
- **Trace pages:** each trace page e2e keeps (its `trace` setting decides which; by default failed, timed-out, interrupted and flaky tests) appears on the test's last attempt as a **walkthrough** attachment. e2e writes them only when the run finishes, so they arrive with the end of the run, within the same 40 seconds. Needs a TestDino server that accepts `test:attachments`; an older one ignores them.
- **Visual comparison:** when an e2e `toHaveScreenshot` check fails (e2e 0.19.0 or later), its expected, actual, and diff images open in TestDino's visual comparison view, as for Playwright. A second comparison of the same name in one attempt (e2e adds `-2`) shows as a plain screenshot.
- **Test Controls** change the build result only under `testdino-e2e run` (see [Run through TestDino in CI](#run-through-testdino-in-ci)).
- **Re-runs** use `npx -p @testdino/e2e testdino-e2e rerun` (see [Re-run failed tests](#re-run-failed-tests)). The dashboard's **Re-run** shows this command for runs uploaded by 1.1.0 or newer. A GitHub Actions retry is narrowed only for jobs that use `testdino-e2e run`. CI suggestions are written for Playwright.

## Updates

When a newer `@testdino/e2e` is published, the `TestDino` line of the e2e summary says so, with the install command. The check asks npm at most once a day and never delays the run. Set `NO_UPDATE_NOTIFIER=1` to turn it off.

## Troubleshooting

| Message on the `TestDino` line                                              | Solution                                                                                                                                                                    |
| --------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `skipped (TESTDINO_TOKEN is not set)`                                       | Set `TESTDINO_TOKEN` where `npx e2e run` runs, or pass `token` to `testdino()`                                                                                              |
| `not recorded (the project is over its execution limit)`                    | Tests still ran, but the run was not saved. Upgrade your plan, or on Pro and Team plans an org admin can add executions for this billing cycle (Settings → Billing & Usage) |
| `not uploaded (no event channel the server offered could be reached)`       | Allow outbound connections from the test machine to TestDino, then run again                                                                                                |
| `upload failed: …`                                                          | The text after the colon names the cause. Run again; if it repeats, contact support with that message                                                                       |
| `shards uploaded as separate runs: set TESTDINO_CI_RUN_ID to merge them`    | Set the same `TESTDINO_CI_RUN_ID` on every shard                                                                                                                            |
| `split ignored: a split position and TESTDINO_SPLIT_ID are needed together` | Set both `TESTDINO_SPLIT` and `TESTDINO_SPLIT_ID` on every job                                                                                                              |

## Security & compliance

ISO 27001 certified · SOC 2 · GDPR compliant. See [Security at TestDino](https://www.testdino.com/security) for details.

## Support

- [Documentation](https://docs.testdino.com/cli/testdino-e2e)
- [Getting Started](https://docs.testdino.com/getting-started)
- [Changelog](https://changelog.testdino.com/?type=cli)
- [Email Support](mailto:support@testdino.com)

---

Copyright 2026 TestDino. All rights reserved. See [LICENSE](./LICENSE).
